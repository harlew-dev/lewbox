# @harlew-dev/ui

Repo: `github.com/harlew-dev/ui` (npm workspace directory `ui/`, package
`@harlew-dev/ui`)
Type: TypeScript/React component library, Tailwind v4, React 19
Purpose: the shared React design system used by every app. It contains **no
auth, API or routing code**.

## What's in it

Components are exported from the barrel (`@harlew-dev/ui`), with deep imports
available per component (`@harlew-dev/ui/button`); charts are the one subpath
exception, since they pull in Recharts.

- **Actions and links**: Button, Clickable, Link, CopyButton, CopyText.
- **Forms**: Input, Textarea, Fieldset/Field/Label/Description/ErrorMessage,
  FieldGroup, Checkbox, RadioGroup, Listbox, Combobox, OtpInput,
  SearchField, TimeRange.
- **Account**: PasswordField, NewPasswordFields, ChangeEmailDialog.
  Password length is the server's policy: neither field sets HTML length
  attributes. `minimumPasswordLength` and `maximumPasswordLength` (and the
  `minLength`/`maxLength` options) were removed; pass the server's
  `requirements` to `NewPasswordFields` instead.
- **MFA**: QrCode, MfaScanStep, CodeField, AppOrRecoveryCode,
  RecoveryCodeList.
- **Overlays**: Dialog, ConfirmationDialog, Dropdown, Tooltip, Toast.
- **Feedback**: Notice/ErrorNotice (with `onRetry`), EmptyState, ListSkeleton, Badge,
  LevelBadge, Reveal, Disclosure.
- **Data**: Table, Pagination, PaginatedTable, DescriptionList, Stat,
  UptimeBar, Calendar, RangeDialog. Charts (`BarChart`, `BarList`,
  `Sparkline`, `Meter`) are on the `@harlew-dev/ui/chart` subpath because
  they use Recharts.
- **Navigation**: Navbar, PageTabs, CursorNav, Sidebar, SideNav,
  TableOfContents, RouteProgress.
- **Layouts**: SidebarLayout, DocsLayout, CenteredLayout, StatusPage (with
  NotFound and ServiceUnavailable), PageTransition. Generic layouts are included;
  app-specific application/admin layouts stay in the app.
- **Typography and bits**: Heading/Subheading/HeadingGroup, PageHeader,
  Text/TextLink/TextButton/Strong/Code, Prose, CodeBlock, CodeTabs, Divider,
  UserIdentity, Steps, Avatar, Highlight, Logo, SettingsSection,
  FilterBadges/FiltersButton.

Helpers such as `cx`, pagination types, date-range formatting and the
`useAction` submission hook are on `@harlew-dev/ui` or `@harlew-dev/ui/lib/*`.
Theme and base CSS ship as `@harlew-dev/ui/styles.css` (also `./theme.css` and
`./base.css`).

## Install

React `>=18.3 <20`, React DOM, Tailwind CSS v4, Base UI, Heroicons and
motion are peer dependencies. Recharts is an optional peer.

### 1. Reference the repo directly

From a sibling checkout:

```json
{ "dependencies": { "@harlew-dev/ui": "file:../ui" } }
```

In an npm/pnpm/yarn workspace, add the same dependency and list the package
directory in `workspaces`; the package manager links it.

A git URL works too, for example `"@harlew-dev/ui":
"github:harlew-dev/ui"`. If the package lives in a subdirectory of a larger
repository, use your package manager's git-path or workspace support to point
at it.

### 2. Install the published package

```sh
npm install @harlew-dev/ui @base-ui/react @heroicons/react motion
```

Add Tailwind v4 and the peers you use (`recharts`) as usual. Install
`@fontsource-variable/inter` if you want the Inter typeface configured by
`theme.css`.

### 3. Copy the source in

The `harlew-ui` CLI copies a component's source and its dependencies into the
app, so the app owns the code:

```sh
npx harlew-ui init
npx harlew-ui add button dialog
npx harlew-ui list
npx harlew-ui diff
```

`init` writes the local aliases/config; `add` copies files into
`components/ui/` and `lib/` and rewrites imports; `list` shows the registry;
`diff` compares copied files with the registry. See `cli/README.md` for the
full CLI reference. This mode does not need the `@harlew-dev/ui` package at
runtime.

## Tailwind setup

Import Tailwind first, then the package styles:

```css
@import "tailwindcss";
@import "@harlew-dev/ui/styles.css";

/* Path relative to this CSS file. Point it at the installed dist. */
@source "../node_modules/@harlew-dev/ui/dist";
```

`@source` is what makes Tailwind generate the utilities used inside the
package; without it the components render unstyled. The path depends on where
your CSS lives:

- **App next to the UI checkout** (`src/styles.css`): `@source
  "../node_modules/@harlew-dev/ui/dist";`.
- **Git URL or published package**: the same path to the installed package's
  `dist` (for example `"../../node_modules/@harlew-dev/ui/dist"` from a
  nested CSS folder, or the pnpm virtual-store path your setup exposes).
- **Copy-in mode**: scan the copied source instead:
  `@source "./components/ui"; @source "./lib";`.

`styles.css` only adds theme tokens/font and element defaults (including the
page's own text and background colours on `<html>`, as Catalyst sets them, so
the area around the layouts matches the theme in dark mode); Preflight and
utilities come from your Tailwind import, so the host app keeps control of
its reset.

## Links

`Link` renders a plain `<a>` with the given `href` and the interactive data
attributes the styles use. Everything that navigates (`Button` with `href`,
`Clickable`, `TextLink`, `Logo`, ...) goes through it.

Some links always stay plain `<a>` elements, even inside a provider:

- `reloadDocument` asks for a full page load: `<Link href="/" reloadDocument>`.
- A non-http(s) scheme: `<Link href="mailto:ada@example.com">`.
- An absolute http(s) or `//` URL on another origin (or any absolute URL when
  rendered on the server): `<Link href="https://example.com">`.
- A `target` other than `_self`, or `download`: `<Link href="/file" download>`.

For client-side navigation, wrap the app once in `LinkProvider` with a
component that accepts `LinkProps` (anchor props plus `href`) and maps `href`
to the router's own prop. React Router:

```tsx
const AppLink = forwardRef<HTMLAnchorElement, LinkProps>(({ href, ...props }, ref) => (
  <RouterLink ref={ref} to={href} {...props} />
));
<LinkProvider component={AppLink}><App /></LinkProvider>
```

Inertia:

```tsx
const AppLink = forwardRef<HTMLAnchorElement, LinkProps>(({ href, ...props }, ref) => (
  <InertiaLink ref={ref as never} href={href} {...props} />
));
<LinkProvider component={AppLink}><App /></LinkProvider>
```

The package ships no router code; these examples are app-side only. Routing
state reaches the components as props:

- `RouteProgress`: `active` (whether the router is navigating).
- `SidebarLayout`: optional `pathname` (closes the mobile sidebar when it
  changes).
- `PageTabs`: `current` (the selected tab).
- `CursorNav`: `search` (a `URLSearchParams`, for its `before` cursor).

## Publishing

Build first; `npm run build` writes ESM, `.d.ts` and shared chunks to `dist/`,
and `files` publishes `dist`, `src`, `registry` and `cli`.

```sh
npm run build
npm publish
```

For GitHub Packages, add a `publishConfig` and authenticate the scope:

```json
{
  "publishConfig": {
    "registry": "https://npm.pkg.github.com",
    "access": "restricted"
  }
}
```

```sh
npm login --registry=https://npm.pkg.github.com
npm publish
```

## Development

```sh
npm run build       # tsup
npm run typecheck   # tsc --noEmit
npm test            # vitest

cd gallery
npm install
npm run dev         # review every component in the browser
npm run typecheck
npm run build
```

The gallery is a standalone Vite + React + Tailwind app that consumes the
package through `file:..`, so it exercises the published entry points,
`LinkProvider` and `@source` setup exactly as a real app would.
