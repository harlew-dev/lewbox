# harlew-ui CLI

Copy `@harlew-dev/ui` source files into your own app, shadcn style. The app
owns the copied components; you can edit them freely.

The CLI reads the registry and source files from the installed package, so it
works from `file:`, git, npm, or a direct path:

```sh
npx --package @harlew-dev/ui harlew-ui add button
npx --package /path/to/ui harlew-ui add dialog sidebar-layout
```

## Setup

```sh
harlew-ui init
```

This writes `harlew-ui.json` with default destinations and prints the Tailwind
`@import`/`@source` lines to add to your CSS entry. Aliases default to
`resources/js/...` or `src/...` when a `src/` directory exists:

```json
{
  "aliases": {
    "components": "resources/js/components/ui",
    "layouts": "resources/js/components/layout",
    "lib": "resources/js/lib/ui",
    "styles": "resources/js/styles/ui"
  }
}
```

Override individual destinations:

```sh
harlew-ui init --components src/components/ui --lib src/lib/ui
```

## Commands

```sh
harlew-ui add button dialog   # copy items and their registry dependencies
harlew-ui add button --all    # copy everything
harlew-ui add button --dry-run
harlew-ui add button --overwrite   # replace files that already exist
harlew-ui list                # items grouped by type, with dependencies
harlew-ui diff button         # unified diff against the registry version
```

`add` rewrites relative imports so copied files keep pointing at each other
after moving into `components/`, `layouts/`, `lib/` and `styles/`.
It also prints the npm packages the copied items need that are not already in
your `package.json`.

`diff` compares an installed copy with the rewritten registry version, which is
useful after the package is updated.

## Notes

- Existing files are skipped with `skip (exists)` unless `--overwrite` is given.
- Add the `styles` item if you want the theme tokens and base defaults:
  `harlew-ui add styles`.
- React must be available; the copied files import bare packages such as
  `@base-ui/react`, `@heroicons/react`, `motion` and `recharts`.
