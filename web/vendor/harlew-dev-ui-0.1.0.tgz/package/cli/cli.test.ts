import { execFileSync } from "node:child_process";
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const cliDir = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(cliDir, "..");
const cli = join(packageRoot, "cli", "index.mjs");
const buildRegistry = join(packageRoot, "scripts", "build-registry.ts");

function run(args: string[], cwd: string): string {
  return execFileSync(process.execPath, [cli, ...args], {
    cwd,
    encoding: "utf8",
  });
}

function makeApp(): string {
  const cwd = mkdtempSync(join(tmpdir(), "harlew-ui-"));
  writeFileSync(join(cwd, "package.json"), '{"name":"x"}\n');
  mkdirSync(join(cwd, "src"));
  return cwd;
}

function walk(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const path = join(dir, entry.name);
    return entry.isDirectory() ? walk(path) : [path];
  });
}

function resolvesToFile(from: string, specifier: string): boolean {
  const base = resolve(dirname(from), specifier);
  return [".ts", ".tsx", ".css", ".js", ".jsx"].some(
    (extension) => existsSync(base + extension) && statSync(base + extension).isFile(),
  );
}

describe("harlew-ui cli", () => {
  it("inits, adds an item with its dependencies, skips, overwrites and diffs", () => {
    const cwd = makeApp();
    run(["init"], cwd);

    const config = JSON.parse(
      readFileSync(join(cwd, "harlew-ui.json"), "utf8"),
    );
    expect(config.aliases.components).toBe("src/components/ui");

    run(["add", "button"], cwd);

    const expected = [
      "src/components/ui/button.tsx",
      "src/components/ui/link.tsx",
      "src/components/ui/tooltip.tsx",
      "src/lib/ui/cx.ts",
      "src/lib/ui/interactive.ts",
      "src/lib/ui/transitions.ts",
    ];
    for (const path of expected) {
      expect(existsSync(join(cwd, path)), path).toBe(true);
    }

    for (const path of walk(join(cwd, "src"))) {
      const source = readFileSync(path, "utf8");
      for (const match of source.matchAll(
        /\b(?:from\s*|import\s*\(\s*)["'](\.\.?\/[^"']+)["']/g,
      )) {
        expect(
          resolvesToFile(path, match[1]),
          `${path} -> ${match[1]}`,
        ).toBe(true);
      }
    }

    const first = run(["add", "button"], cwd);
    expect(first).toContain("skip (exists)");

    const buttonPath = join(cwd, "src/components/ui/button.tsx");
    writeFileSync(buttonPath, "// edited\n");
    run(["add", "button", "--overwrite"], cwd);
    expect(readFileSync(buttonPath, "utf8")).not.toBe("// edited\n");

    const diff = run(["diff", "button"], cwd);
    expect(diff).toContain("no changes");
  });

  it("keeps registry/registry.json up to date", () => {
    const cwd = mkdtempSync(join(tmpdir(), "harlew-registry-"));
    const out = join(cwd, "registry.json");
    execFileSync(process.execPath, [
      "--experimental-strip-types",
      buildRegistry,
      "--out",
      out,
    ]);
    const generated = readFileSync(out, "utf8");
    const committed = readFileSync(
      join(packageRoot, "registry", "registry.json"),
      "utf8",
    );
    expect(generated).toBe(committed);
  });
});
