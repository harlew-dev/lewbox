#!/usr/bin/env node
import {
  existsSync,
  mkdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = resolve(__dirname, "..");
const REGISTRY_PATH = join(PACKAGE_ROOT, "registry", "registry.json");

const EXTENSIONS = [".ts", ".tsx", ".css", ".js", ".jsx", ".mjs"];
const TYPE_ORDER = ["component", "layout", "lib", "style"];

function toPosix(value) {
  return value.split(sep).join("/");
}

function stripExtension(file) {
  for (const extension of EXTENSIONS) {
    if (file.endsWith(extension)) return file.slice(0, -extension.length);
  }
  return file;
}

function loadRegistry() {
  if (!existsSync(REGISTRY_PATH)) {
    throw new Error(
      `registry not found at ${REGISTRY_PATH}; run "npm run registry" in the package`,
    );
  }
  return JSON.parse(readFileSync(REGISTRY_PATH, "utf8"));
}

function buildSourceIndex(registry) {
  const index = new Map();
  for (const item of registry.items) {
    for (const file of item.files) {
      index.set(stripExtension(join(PACKAGE_ROOT, file.path)), { item, file });
    }
  }
  return index;
}

function resolveExport(from, specifier) {
  const base = resolve(dirname(from), specifier);
  const candidates = [
    base,
    ...EXTENSIONS.map((extension) => base + extension),
    ...EXTENSIONS.map((extension) => join(base, `index${extension}`)),
  ];
  for (const candidate of candidates) {
    if (existsSync(candidate) && statSync(candidate).isFile()) {
      return stripExtension(candidate);
    }
  }
  return null;
}

function parseArgs(argv) {
  const positionals = [];
  const flags = {};
  const valueFlags = new Set([
    "--cwd",
    "--components",
    "--layouts",
    "--lib",
    "--styles",
  ]);
  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === "--") {
      positionals.push(...argv.slice(index + 1));
      break;
    }
    if (argument.startsWith("--")) {
      if (valueFlags.has(argument)) {
        const value = argv[index + 1];
        if (value === undefined) throw new Error(`${argument} needs a value`);
        flags[argument.slice(2)] = value;
        index += 1;
      } else {
        flags[argument.slice(2)] = true;
      }
    } else {
      positionals.push(argument);
    }
  }
  return { positionals, flags };
}

function detectBase(cwd) {
  if (existsSync(join(cwd, "resources", "js"))) return "resources/js";
  if (existsSync(join(cwd, "src"))) return "src";
  return "resources/js";
}

function defaultAliases(cwd) {
  const base = detectBase(cwd);
  return {
    components: `${base}/components/ui`,
    layouts: `${base}/components/layout`,
    lib: `${base}/lib/ui`,
    styles: `${base}/styles/ui`,
  };
}

function readConfig(cwd) {
  const path = join(cwd, "harlew-ui.json");
  if (!existsSync(path)) {
    throw new Error(`no harlew-ui.json in ${cwd}; run "harlew-ui init" first`);
  }
  const config = JSON.parse(readFileSync(path, "utf8"));
  if (!config.aliases) {
    throw new Error(`invalid harlew-ui.json in ${cwd}: missing "aliases"`);
  }
  return config;
}

function destinationFor(cwd, config, item, file) {
  const alias = config.aliases[file.target];
  if (!alias) {
    throw new Error(
      `no "${file.target}" alias in harlew-ui.json (needed by ${item.name})`,
    );
  }
  return join(resolve(cwd, alias), basename(file.path));
}

function rewriteFile(sourcePath, destPath, index, cwd, config) {
  const sourceDir = dirname(sourcePath);
  const destDir = dirname(destPath);
  let text = readFileSync(sourcePath, "utf8");
  const pattern = /(["'])(\.\.?\/[^"']+)\1/g;
  text = text.replace(pattern, (match, quote, specifier) => {
    const resolved = resolveExport(sourcePath, specifier);
    const dependency = resolved ? index.get(resolved) : null;
    if (!dependency) return match;
    const dependencyDest = destinationFor(
      cwd,
      config,
      dependency.item,
      dependency.file,
    );
    let replacement = toPosix(
      relative(destDir, stripExtension(dependencyDest)),
    );
    if (!replacement.startsWith(".")) replacement = `./${replacement}`;
    if (specifier.endsWith(".css")) replacement += ".css";
    return `${quote}${replacement}${quote}`;
  });
  return text;
}

function resolveItems(registry, names, all) {
  const byName = new Map(registry.items.map((item) => [item.name, item]));
  const requested = all ? [...byName.keys()] : names;
  if (requested.length === 0) {
    throw new Error("no items given (try --all or a list of names)");
  }

  const ordered = [];
  const state = new Map();

  function visit(name) {
    if (state.get(name) === "done") return;
    if (state.get(name) === "visiting") return;
    const item = byName.get(name);
    if (!item) throw new Error(`unknown item "${name}"`);
    state.set(name, "visiting");
    for (const dependency of item.registryDependencies) visit(dependency);
    state.set(name, "done");
    ordered.push(item);
  }

  for (const name of requested) visit(name);
  return ordered;
}

function appDependencies(cwd) {
  const path = join(cwd, "package.json");
  if (!existsSync(path)) return new Set();
  const pkg = JSON.parse(readFileSync(path, "utf8"));
  return new Set([
    ...Object.keys(pkg.dependencies ?? {}),
    ...Object.keys(pkg.devDependencies ?? {}),
    ...Object.keys(pkg.peerDependencies ?? {}),
  ]);
}

function printInstallDependencies(items, cwd) {
  const installed = appDependencies(cwd);
  const dependencies = new Set();
  for (const item of items) {
    for (const dependency of item.dependencies) dependencies.add(dependency);
  }
  const missing = [...dependencies].filter((name) => !installed.has(name)).sort();
  if (missing.length > 0) {
    console.log(`\nInstall dependencies:\n  npm i ${missing.join(" ")}`);
  }
}

function init(flags) {
  const cwd = resolve(flags.cwd ?? process.cwd());
  const aliases = defaultAliases(cwd);
  for (const key of ["components", "layouts", "lib", "styles"]) {
    if (flags[key]) aliases[key] = flags[key];
  }
  const config = { aliases };
  const path = join(cwd, "harlew-ui.json");
  writeFileSync(path, `${JSON.stringify(config, null, 2)}\n`);
  console.log(`Created ${toPosix(relative(process.cwd(), path))}`);
  for (const [key, value] of Object.entries(aliases)) {
    console.log(`  ${key}: ${value}`);
  }
  const stylesPath = toPosix(relative(cwd, resolve(cwd, aliases.styles)));
  console.log(
    "\nAdd this to your Tailwind CSS entry (after installing the styles item):",
  );
  console.log(`  @import "./${stylesPath}/index.css";`);
  console.log(
    `  @source "./${toPosix(relative(cwd, resolve(cwd, aliases.components)))}";`,
  );
}

function add(positionals, flags) {
  const cwd = resolve(flags.cwd ?? process.cwd());
  const config = readConfig(cwd);
  const registry = loadRegistry();
  const index = buildSourceIndex(registry);
  const items = resolveItems(registry, positionals, Boolean(flags.all));

  for (const item of items) {
    for (const file of item.files) {
      const sourcePath = join(PACKAGE_ROOT, file.path);
      const destPath = destinationFor(cwd, config, item, file);
      const shown = toPosix(relative(cwd, destPath));
      if (existsSync(destPath) && !flags.overwrite) {
        console.log(`skip (exists) ${shown}`);
        continue;
      }
      if (flags["dry-run"]) {
        console.log(`would add ${shown}`);
        continue;
      }
      const content = rewriteFile(sourcePath, destPath, index, cwd, config);
      mkdirSync(dirname(destPath), { recursive: true });
      writeFileSync(destPath, content);
      console.log(`added ${shown}`);
    }
  }

  printInstallDependencies(items, cwd);
}

function list() {
  const registry = loadRegistry();
  for (const type of TYPE_ORDER) {
    const items = registry.items
      .filter((item) => item.type === type)
      .sort((a, b) => a.name.localeCompare(b.name));
    if (items.length === 0) continue;
    console.log(`\n${type}s`);
    for (const item of items) {
      const parts = [];
      if (item.registryDependencies.length > 0) {
        parts.push(`deps: ${item.registryDependencies.join(", ")}`);
      }
      if (item.dependencies.length > 0) {
        parts.push(`npm: ${item.dependencies.join(", ")}`);
      }
      console.log(`  ${item.name}${parts.length ? `  (${parts.join("; ")})` : ""}`);
    }
  }
}

function diffLines(aText, bText, aLabel, bLabel, context = 3) {
  const a = aText.split("\n");
  const b = bText.split("\n");
  const table = Array.from({ length: a.length + 1 }, () =>
    new Array(b.length + 1).fill(0),
  );
  for (let i = a.length - 1; i >= 0; i -= 1) {
    for (let j = b.length - 1; j >= 0; j -= 1) {
      table[i][j] =
        a[i] === b[j]
          ? table[i + 1][j + 1] + 1
          : Math.max(table[i + 1][j], table[i][j + 1]);
    }
  }

  const ops = [];
  let i = 0;
  let j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      ops.push({ type: " ", line: a[i] });
      i += 1;
      j += 1;
    } else if (table[i + 1][j] >= table[i][j + 1]) {
      ops.push({ type: "-", line: a[i] });
      i += 1;
    } else {
      ops.push({ type: "+", line: b[j] });
      j += 1;
    }
  }
  while (i < a.length) {
    ops.push({ type: "-", line: a[i] });
    i += 1;
  }
  while (j < b.length) {
    ops.push({ type: "+", line: b[j] });
    j += 1;
  }

  if (!ops.some((op) => op.type !== " ")) return "";

  const lines = [`--- ${aLabel}`, `+++ ${bLabel}`];
  const changed = ops
    .map((op, index) => (op.type === " " ? -1 : index))
    .filter((index) => index >= 0);
  let cursor = 0;
  while (cursor < changed.length) {
    let first = changed[cursor];
    let last = first;
    while (
      cursor + 1 < changed.length &&
      changed[cursor + 1] - last <= context * 2
    ) {
      cursor += 1;
      last = changed[cursor];
    }
    const start = Math.max(0, first - context);
    const end = Math.min(ops.length, last + context + 1);
    let aStart = 1;
    let bStart = 1;
    for (let index = 0; index < start; index += 1) {
      if (ops[index].type !== "+") aStart += 1;
      if (ops[index].type !== "-") bStart += 1;
    }
    let aCount = 0;
    let bCount = 0;
    for (let index = start; index < end; index += 1) {
      if (ops[index].type !== "+") aCount += 1;
      if (ops[index].type !== "-") bCount += 1;
    }
    lines.push(`@@ -${aStart},${aCount} +${bStart},${bCount} @@`);
    for (let index = start; index < end; index += 1) {
      lines.push(`${ops[index].type}${ops[index].line}`);
    }
    cursor += 1;
  }
  return `${lines.join("\n")}\n`;
}

function diff(itemName, flags) {
  const cwd = resolve(flags.cwd ?? process.cwd());
  const config = readConfig(cwd);
  const registry = loadRegistry();
  const index = buildSourceIndex(registry);
  const item = registry.items.find((candidate) => candidate.name === itemName);
  if (!item) throw new Error(`unknown item "${itemName}"`);

  for (const file of item.files) {
    const sourcePath = join(PACKAGE_ROOT, file.path);
    const destPath = destinationFor(cwd, config, item, file);
    const shown = toPosix(relative(cwd, destPath));
    if (!existsSync(destPath)) {
      console.log(`${shown}: not installed`);
      continue;
    }
    const installed = readFileSync(destPath, "utf8");
    const expected = rewriteFile(sourcePath, destPath, index, cwd, config);
    if (installed === expected) {
      console.log(`${shown}: no changes`);
      continue;
    }
    process.stdout.write(
      diffLines(installed, expected, `installed/${shown}`, `registry/${file.path}`),
    );
  }
}

function usage() {
  console.log(`harlew-ui - copy @harlew-dev/ui source into your app

Usage:
  harlew-ui init [--components <dir>] [--layouts <dir>] [--lib <dir>]
                 [--styles <dir>] [--cwd <dir>]
  harlew-ui add <item...> [--all] [--overwrite] [--dry-run] [--cwd <dir>]
  harlew-ui list
  harlew-ui diff <item> [--cwd <dir>]`);
}

function main() {
  const [command, ...rest] = process.argv.slice(2);
  const { positionals, flags } = parseArgs(rest);

  if (!command || flags.help) {
    usage();
    return;
  }
  if (command === "init") return init(flags);
  if (command === "add") return add(positionals, flags);
  if (command === "list") return list();
  if (command === "diff") {
    if (positionals.length !== 1) {
      throw new Error("diff needs exactly one item name");
    }
    return diff(positionals[0], flags);
  }
  throw new Error(`unknown command "${command}"`);
}

try {
  main();
} catch (error) {
  console.error(`harlew-ui: ${error instanceof Error ? error.message : error}`);
  process.exitCode = 1;
}
