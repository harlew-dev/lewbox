import { useState, type ReactNode } from "react";
import { NavbarItem } from "../components/ui/navbar";
import { SidebarToggle } from "../components/ui/sidebar";
import { MobileSidebar, OpenMenuIcon } from "./mobile-sidebar";

// DocsLayout: documentation and other reading pages, as on the Catalyst docs
// site. A header bar across the top (the logo, then `navbar` on the right: a
// few links, the way back to the app), the page list (`nav`, usually a
// SideNav) in a sticky column on the left, and the page on a plain
// background, with no inset card. On small screens the page list moves into
// the same slide-over panel SidebarLayout uses, opened from the header.
//
// The page arranges its own content; for an "On this page" column, put a
// TableOfContents in a sticky aside beside the article (top-26 clears the
// header).
export function DocsLayout({
  logo,
  navbar,
  nav,
  pathname,
  children,
}: {
  logo: ReactNode;
  navbar?: ReactNode;
  nav: ReactNode;
  // The app's current pathname: when it changes, the mobile panel closes.
  // Links inside the panel also close it, so this stays optional.
  pathname?: string;
  children: ReactNode;
}) {
  const [showNav, setShowNav] = useState(false);
  const [shownFor, setShownFor] = useState(pathname);
  if (pathname !== shownFor) {
    setShownFor(pathname);
    setShowNav(false);
  }
  return (
    <div className="isolate flex min-h-dvh w-full flex-col bg-white dark:bg-zinc-900">
      <a
        href="#main"
        className="fixed top-2 left-2 z-50 -translate-y-20 rounded-lg bg-white px-3 py-2 text-sm font-medium shadow-sm ring-1 ring-zinc-950/10 focus:translate-y-0 dark:bg-zinc-900 dark:ring-white/10"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-zinc-950/5 bg-white/90 backdrop-blur-sm dark:border-white/5 dark:bg-zinc-900/90">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
          <div className="-ml-2 lg:hidden">
            <NavbarItem
              onClick={() => setShowNav(true)}
              aria-label="Open navigation"
            >
              <OpenMenuIcon />
            </NavbarItem>
          </div>
          <div className="shrink-0">{logo}</div>
          <div className="flex min-w-0 flex-1 justify-end">{navbar}</div>
        </div>
      </header>
      <MobileSidebar open={showNav} close={() => setShowNav(false)}>
        <div className="flex items-center justify-between gap-2 border-b border-zinc-950/5 p-4 dark:border-white/5">
          {logo}
          <SidebarToggle />
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-6">{nav}</div>
      </MobileSidebar>
      <div className="mx-auto flex w-full max-w-7xl flex-1 gap-x-12 px-4 sm:px-6 lg:px-8 xl:gap-x-16">
        {/* -ml-1 pl-1: room for the current bar, which overhangs the nav's
            rule, inside the scrolling column. */}
        <aside className="sticky top-16 hidden max-h-[calc(100dvh-(--spacing(16)))] w-56 shrink-0 self-start overflow-y-auto pt-10 pb-16 -ml-1 pl-1 lg:block">
          {nav}
        </aside>
        <main id="main" className="min-w-0 flex-1 pt-10 pb-24">
          {children}
        </main>
      </div>
    </div>
  );
}
