import {
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { DocsLayout } from "./docs-layout";

function renderLayout(pathname = "/docs") {
  return render(
    <DocsLayout
      logo={<span>Logo</span>}
      navbar={<a href="/">Console</a>}
      nav={
        <nav aria-label="Pages">
          <a href="/docs/next" onClick={(event) => event.preventDefault()}>
            Next page
          </a>
        </nav>
      }
      pathname={pathname}
    >
      <p>Page content</p>
    </DocsLayout>,
  );
}

describe("<DocsLayout>", () => {
  it("shows the header, the page list and the page", () => {
    renderLayout();
    expect(screen.getByRole("banner")).toHaveTextContent("Logo");
    expect(screen.getByRole("link", { name: "Console" })).toBeInTheDocument();
    expect(screen.getByRole("main")).toHaveTextContent("Page content");
    expect(screen.getByRole("navigation", { name: "Pages" })).toBeInTheDocument();
  });

  it("opens the page list in a panel on small screens, which a link closes", async () => {
    renderLayout();
    fireEvent.click(screen.getByRole("button", { name: "Open navigation" }));
    const dialog = await screen.findByRole("dialog", { name: "Navigation" });
    fireEvent.click(within(dialog).getByRole("link", { name: "Next page" }));
    await waitFor(() =>
      expect(
        screen.queryByRole("dialog", { name: "Navigation" }),
      ).not.toBeInTheDocument(),
    );
  });

  it("closes the panel when the page changes", async () => {
    const { rerender } = renderLayout("/docs");
    fireEvent.click(screen.getByRole("button", { name: "Open navigation" }));
    await screen.findByRole("dialog", { name: "Navigation" });
    rerender(
      <DocsLayout logo={<span>Logo</span>} nav={<nav />} pathname="/docs/other">
        <p>Other page</p>
      </DocsLayout>,
    );
    await waitFor(() =>
      expect(
        screen.queryByRole("dialog", { name: "Navigation" }),
      ).not.toBeInTheDocument(),
    );
  });
});
