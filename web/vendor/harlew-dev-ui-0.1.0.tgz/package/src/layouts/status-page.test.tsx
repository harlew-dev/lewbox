import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { ServiceUnavailable } from "./status-page";
describe("outage page", () => {
  it("shows the failed request's reference, when there is one", () => {
    render(<ServiceUnavailable requestId="req_2yEHYLwiwPVhLW" />);
    expect(screen.getByRole("heading")).toHaveTextContent("A brief pause.");
    expect(screen.getByText(/Reference:/)).toHaveTextContent(
      "Reference: req_2yEHYLwiwPVhLW",
    );
  });
  it("shows none for a network failure", () => {
    render(<ServiceUnavailable />);
    expect(screen.queryByText(/Reference/)).toBeNull();
  });
});
