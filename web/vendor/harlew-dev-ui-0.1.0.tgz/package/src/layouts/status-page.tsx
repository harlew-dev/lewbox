import type { ReactNode } from "react";
import { Button } from "../components/ui/button";
import { Reference } from "../components/ui/feedback";
import { Heading, HeadingGroup } from "../components/ui/heading";
import { Text } from "../components/ui/text";
import { CenteredLayout } from "./centered-layout";
// Full-page message (homepage, 404, service outage) in the centered layout,
// with a failure's reference under the description when there is one.
export function StatusPage({
  title,
  description,
  action,
  logo,
  footer,
  requestId,
}: {
  title: string;
  description: string;
  action: ReactNode;
  // The wordmark above the message; the app passes its own.
  logo?: ReactNode;
  // Below the card (the homepage's policy links).
  footer?: ReactNode;
  requestId?: string;
}) {
  return (
    <CenteredLayout footer={footer}>
      <div className="grid w-full max-w-sm grid-cols-1 gap-8">
        {logo}
        <HeadingGroup>
          <Heading>{title}</Heading>
          <Text>{description}</Text>
          {requestId && (
            <Text>
              <Reference requestId={requestId} />
            </Text>
          )}
        </HeadingGroup>
        <div>{action}</div>
      </div>
    </CenteredLayout>
  );
}
// Unknown URLs, and records that don't exist or aren't the viewer's. The
// caller supplies where "back" goes.
export function NotFound({
  href,
  reloadDocument,
  logo,
}: {
  href: string;
  reloadDocument?: boolean;
  logo?: ReactNode;
}) {
  return (
    <StatusPage
      title="This page has wandered off."
      description="Let’s get you back to where you were."
      logo={logo}
      action={
        <Button href={href} reloadDocument={reloadDocument}>
          Back
        </Button>
      }
    />
  );
}
// The outage page. requestId is the failed request's ID, when the server sent
// one (a 500): its reference, for support to find the log line.
export function ServiceUnavailable({
  requestId,
  logo,
}: {
  requestId?: string;
  logo?: ReactNode;
}) {
  return (
    <StatusPage
      title="A brief pause."
      description="We’re having trouble reaching the service. Your data is safe — please try again in a moment."
      logo={logo}
      requestId={requestId}
      action={
        <Button onClick={() => window.location.reload()}>Try again</Button>
      }
    />
  );
}
