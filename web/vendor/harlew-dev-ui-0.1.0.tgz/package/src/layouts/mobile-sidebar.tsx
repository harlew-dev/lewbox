import type { ReactNode } from "react";
import { Dialog } from "@base-ui/react/dialog";
import {
  SidebarCloseContext,
  SidebarToggleContext,
} from "../components/ui/sidebar-context";
// Shared by SidebarLayout and DocsLayout: the menu icons and the slide-over
// panel that holds the navigation on small screens.
export function OpenMenuIcon() {
  return (
    <svg data-slot="icon" viewBox="0 0 20 20" aria-hidden="true">
      <path d="M2 6.75C2 6.33579 2.33579 6 2.75 6H17.25C17.6642 6 18 6.33579 18 6.75C18 7.16421 17.6642 7.5 17.25 7.5H2.75C2.33579 7.5 2 7.16421 2 6.75ZM2 13.25C2 12.8358 2.33579 12.5 2.75 12.5H17.25C17.6642 12.5 18 12.8358 18 13.25C18 13.6642 17.6642 14 17.25 14H2.75C2.33579 14 2 13.6642 2 13.25Z" />
    </svg>
  );
}
export function CloseMenuIcon() {
  return (
    <svg data-slot="icon" viewBox="0 0 20 20" aria-hidden="true">
      <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
    </svg>
  );
}
// The mobile sidebar is a Base UI Dialog (focus trap, Escape, backdrop click,
// scroll lock) styled as a slide-over panel from the left.
const backdropClasses =
  "fixed inset-0 z-50 bg-black/30 transition duration-300 ease-out data-starting-style:opacity-0 data-ending-style:opacity-0 motion-reduce:transition-none lg:hidden";
const popupClasses =
  "fixed inset-y-0 left-0 z-50 w-full max-w-80 p-2 transition duration-300 ease-in-out data-starting-style:-translate-x-full data-ending-style:-translate-x-full motion-reduce:transition-none lg:hidden";
const panelClasses =
  "flex h-full flex-col rounded-lg bg-white shadow-xs ring-1 ring-zinc-950/5 dark:bg-zinc-900 dark:ring-white/10";
export function MobileSidebar({
  open,
  close,
  children,
}: {
  open: boolean;
  close: () => void;
  children: ReactNode;
}) {
  return (
    <Dialog.Root
      open={open}
      onOpenChange={(next) => {
        if (!next) close();
      }}
    >
      <Dialog.Portal>
        <Dialog.Backdrop className={backdropClasses} />
        <Dialog.Popup aria-label="Navigation" className={popupClasses}>
          <div
            className={panelClasses}
            onClick={(event) => {
              if (
                event.target instanceof Element &&
                event.target.closest("a")
              )
                close();
            }}
          >
            <SidebarToggleContext.Provider
              value={{
                label: "Close navigation",
                icon: <CloseMenuIcon />,
                onClick: close,
              }}
            >
              <SidebarCloseContext.Provider value={close}>
                {children}
              </SidebarCloseContext.Provider>
            </SidebarToggleContext.Provider>
          </div>
        </Dialog.Popup>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
