import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { PageTransition } from "./page-transition";

describe("<PageTransition>", () => {
  it("renders its content inside the transition wrapper", () => {
    const { container } = render(
      <PageTransition>
        <p>Page content</p>
      </PageTransition>,
    );
    expect(screen.getByText("Page content")).toBeInTheDocument();
    expect(container.firstElementChild).toHaveClass("starting:opacity-0");
  });
  it("slides in from the requested side", () => {
    const { container } = render(
      <PageTransition from="right">
        <p>Tab content</p>
      </PageTransition>,
    );
    expect(container.firstElementChild).toHaveClass("starting:translate-x-3");
  });
});
