import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import {
  NewPasswordFields,
  PasswordField,
  newPasswordProblems,
} from "./password-fields";

describe("PasswordField", () => {
  it("shows and hides the password with its eye toggle", () => {
    render(
      <PasswordField
        label="Current password"
        autoComplete="current-password"
        value="hunter2"
        onChange={() => {}}
        disabled={false}
      />,
    );
    const field = screen.getByLabelText("Current password");
    expect(field).toHaveAttribute("type", "password");
    fireEvent.click(screen.getByRole("button", { name: "Show password text" }));
    expect(field).toHaveAttribute("type", "text");
    fireEvent.click(screen.getByRole("button", { name: "Hide password text" }));
    expect(field).toHaveAttribute("type", "password");
  });
  it("shows a field error", () => {
    render(
      <PasswordField
        label="Current password"
        autoComplete="current-password"
        value=""
        onChange={() => {}}
        error="Enter your current password."
        disabled={false}
      />,
    );
    expect(screen.getByRole("alert")).toHaveTextContent(
      "Enter your current password.",
    );
    expect(screen.getByLabelText("Current password")).toHaveAttribute(
      "aria-invalid",
      "true",
    );
  });
  it("accepts a short password and sets no minLength", () => {
    render(
      <PasswordField
        label="Current password"
        autoComplete="current-password"
        value="password"
        onChange={() => {}}
        disabled={false}
      />,
    );
    const field = screen.getByLabelText("Current password");
    expect(field).toHaveValue("password");
    expect(field).not.toHaveAttribute("minLength");
    expect(field).not.toHaveAttribute("maxLength");
    expect(field).toBeRequired();
  });
});

describe("newPasswordProblems()", () => {
  it("requires a new password and a matching confirmation", () => {
    expect(newPasswordProblems("", "")).toEqual({
      newPassword: "Enter a new password.",
    });
    expect(newPasswordProblems("password", "different")).toEqual({
      confirmation: "The passwords don’t match.",
    });
    expect(newPasswordProblems("password", "password")).toEqual({});
  });
  it("doesn't reject a short password", () => {
    expect(newPasswordProblems("short", "short")).toEqual({});
  });
});

describe("NewPasswordFields", () => {
  it("names both fields and shows the rules and errors it is given", () => {
    render(
      <NewPasswordFields
        password=""
        confirmation=""
        onPasswordChange={() => {}}
        onConfirmationChange={() => {}}
        errors={{ newPassword: "Use a longer password." }}
        requirements={["At least one number.", "One symbol."]}
      />,
    );
    expect(screen.getByLabelText("New password")).toBeInTheDocument();
    expect(screen.getByLabelText("Confirm new password")).toBeInTheDocument();
    expect(screen.getByText("At least one number. One symbol.")).toBeInTheDocument();
    expect(screen.getByRole("alert")).toHaveTextContent(
      "Use a longer password.",
    );
  });
  it("sets no length constraints and shows no hard-coded rules", () => {
    render(
      <NewPasswordFields
        password=""
        confirmation=""
        onPasswordChange={() => {}}
        onConfirmationChange={() => {}}
        errors={{}}
      />,
    );
    const field = screen.getByLabelText("New password");
    expect(field).not.toHaveAttribute("minLength");
    expect(field).not.toHaveAttribute("maxLength");
    expect(screen.queryByText(/At least \d+ characters/)).not.toBeInTheDocument();
  });
});
