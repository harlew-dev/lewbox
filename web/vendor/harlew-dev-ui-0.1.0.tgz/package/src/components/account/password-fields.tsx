import {
  Description,
  ErrorMessage,
  Field,
  FieldGroup,
  Label,
} from "../ui/fieldset";
import { Input } from "../ui/input";
// The server owns the password policy. These fields only show the
// requirements it passes in and report the browser errors the app already
// knows about; they never set length constraints of their own.
export type PasswordRules = {
  // What the password must contain, shown under the first field. The server
  // checks them; this component only displays them.
  requirements?: string[];
};
// Checks the browser can make before sending a new password: errors keyed
// "newPassword" or "confirmation", for NewPasswordFields. Length rules belong
// to the server.
export function newPasswordProblems(
  password: string,
  confirmation: string,
): Record<string, string> {
  if (password === "") return { newPassword: "Enter a new password." };
  if (password !== confirmation)
    return { confirmation: "The passwords don’t match." };
  return {};
}
export function PasswordField({
  label,
  description,
  autoComplete,
  value,
  onChange,
  error,
  disabled = false,
  autoFocus = true,
  required = true,
}: {
  label: string;
  description?: string;
  autoComplete: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  required?: boolean;
}) {
  return (
    <Field disabled={disabled}>
      <Label>{label}</Label>
      {description && <Description>{description}</Description>}
      <Input
        type="password"
        autoComplete={autoComplete}
        autoFocus={autoFocus}
        required={required}
        invalid={Boolean(error)}
        value={value}
        onChange={(e) => onChange(e.currentTarget.value)}
      />
      {error && <ErrorMessage role="alert">{error}</ErrorMessage>}
    </Field>
  );
}
// A new password and its confirmation. `errors` holds messages keyed
// "newPassword" and "confirmation" (newPasswordProblems, or the API's field).
export function NewPasswordFields({
  password,
  confirmation,
  onPasswordChange,
  onConfirmationChange,
  errors,
  disabled = false,
  requirements,
}: {
  password: string;
  confirmation: string;
  onPasswordChange: (value: string) => void;
  onConfirmationChange: (value: string) => void;
  errors: Record<string, string>;
  disabled?: boolean;
  requirements?: string[];
}) {
  return (
    <FieldGroup>
      <PasswordField
        label="New password"
        description={requirements?.length ? requirements.join(" ") : undefined}
        autoComplete="new-password"
        value={password}
        onChange={onPasswordChange}
        error={errors.newPassword}
        disabled={disabled}
      />
      <PasswordField
        label="Confirm new password"
        autoComplete="new-password"
        value={confirmation}
        onChange={onConfirmationChange}
        error={errors.confirmation}
        disabled={disabled}
        autoFocus={false}
      />
    </FieldGroup>
  );
}
