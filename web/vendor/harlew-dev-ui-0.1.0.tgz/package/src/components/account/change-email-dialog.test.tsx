import { useState } from "react";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import {
  ChangeEmailDialog,
  type ChangeEmailDialogProps,
} from "./change-email-dialog";

function renderDialog(overrides: Partial<ChangeEmailDialogProps> = {}) {
  const onClose = vi.fn();
  const onChanged = vi.fn();
  const onRequest = vi.fn(async () => {});
  const onConfirm = vi.fn(async () => {});
  const onCancelChange = vi.fn(async () => {});
  const order: string[] = [];
  onChanged.mockImplementation((email: string) => {
    order.push(`changed:${email}`);
  });
  const close = () => {
    order.push("close");
    onClose();
  };
  function Demo() {
    const [open, setOpen] = useState(true);
    return (
      <>
        <p>{open ? "Open" : "Closed"}</p>
        <ChangeEmailDialog
          open={open}
          onClose={() => {
            close();
            setOpen(false);
          }}
          mfaEnabled={false}
          onRequest={onRequest}
          onConfirm={onConfirm}
          onCancelChange={onCancelChange}
          onChanged={onChanged}
          {...overrides}
        />
      </>
    );
  }
  render(<Demo />);
  return { onClose, onChanged, onRequest, onConfirm, onCancelChange, order };
}
function type(label: string, value: string) {
  fireEvent.change(screen.getByLabelText(label), { target: { value } });
}
async function dismissSuccess(onChanged: ReturnType<typeof vi.fn>) {
  expect(
    await screen.findByRole("heading", { name: "Email address changed" }),
  ).toBeInTheDocument();
  expect(screen.getByText(/Your sign-in email is now/)).toHaveTextContent(
    "new@example.test",
  );
  expect(onChanged).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole("button", { name: "Done" }));
  await waitFor(() =>
    expect(onChanged).toHaveBeenCalledWith("new@example.test"),
  );
  await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
}

describe("ChangeEmailDialog", () => {
  it("walks from a new address through account access and the emailed code", async () => {
    const { onRequest, onConfirm, onChanged, order } = renderDialog();
    await screen.findByLabelText("New email address");
    type("New email address", "new@example.test");
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    expect(screen.getByText("new@example.test")).toBeInTheDocument();
    type("Current password", "my current password");
    fireEvent.click(screen.getByRole("button", { name: "Send code" }));
    expect(await screen.findByLabelText("Email change code")).toBeInTheDocument();
    expect(onRequest).toHaveBeenCalledWith({
      email: "new@example.test",
      password: "my current password",
    });
    type("Email change code", "123456");
    await dismissSuccess(onChanged);
    expect(onConfirm).toHaveBeenCalledWith("123456");
    // onChanged runs before onClose.
    expect(order).toEqual(["changed:new@example.test", "close"]);
  });

  it("confirms directly without a code when verification is off", async () => {
    let finishRequest!: (value: unknown) => void;
    const onRequest = vi.fn(
      () =>
        new Promise<unknown>((resolve) => {
          finishRequest = resolve;
        }),
    );
    const { onConfirm, onChanged } = renderDialog({
      verification: false,
      pending: { email: "pending@example.test" },
      onRequest,
    });
    // A pending request is not resumed when no code can be sent.
    await screen.findByLabelText("New email address");
    type("New email address", "new@example.test");
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    expect(screen.getByText("new@example.test")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Confirm" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Send code" })).toBeNull();
    type("Current password", "my current password");
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    expect(screen.queryByLabelText("Email change code")).toBeNull();
    finishRequest({ done: true });
    await dismissSuccess(onChanged);
    expect(screen.queryByLabelText("Email change code")).toBeNull();
    expect(onConfirm).not.toHaveBeenCalled();
  });

  it("finishes without a code when the request reports done", async () => {
    const onRequest = vi.fn(async () => ({ done: true }));
    const { onConfirm, onChanged } = renderDialog({ onRequest });
    await screen.findByLabelText("New email address");
    type("New email address", "new@example.test");
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    type("Current password", "my current password");
    fireEvent.click(screen.getByRole("button", { name: "Send code" }));
    await dismissSuccess(onChanged);
    expect(screen.queryByLabelText("Email change code")).toBeNull();
    expect(onConfirm).not.toHaveBeenCalled();
  });

  it("resumes a pending request at its code", async () => {
    const { onRequest } = renderDialog({
      pending: {
        email: "new@example.test",
        expiresAt: "2030-01-01T12:15:00Z",
      },
    });
    await screen.findByLabelText("Email change code");
    expect(screen.getByText(/Requested address:/)).toHaveTextContent(
      "new@example.test",
    );
    expect(onRequest).not.toHaveBeenCalled();
    expect(
      within(screen.getByRole("dialog"))
        .getAllByRole("button")
        .map((button) => button.textContent),
    ).toEqual(
      expect.arrayContaining([
        "Close",
        "Cancel change",
        "Change email address",
      ]),
    );
  });

  it("ends on the cancelled screen with only a Close button", async () => {
    const { onCancelChange } = renderDialog({
      pending: { email: "new@example.test" },
    });
    await screen.findByLabelText("Email change code");
    fireEvent.click(screen.getByRole("button", { name: "Cancel change" }));
    expect(
      await screen.findByRole("heading", {
        name: "Your change has been cancelled",
      }),
    ).toBeInTheDocument();
    expect(onCancelChange).toHaveBeenCalledTimes(1);
    expect(
      within(screen.getByRole("dialog"))
        .getAllByRole("button")
        .map((button) => button.textContent),
    ).toEqual(["Close"]);
    expect(screen.queryByLabelText("New email address")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Close" }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  });

  it("shows a field failure inline and lets the code be retried", async () => {
    const onConfirm = vi
      .fn<() => Promise<unknown>>()
      .mockRejectedValueOnce(
        Object.assign(new Error("Wrong email code."), { field: "code" }),
      )
      .mockResolvedValueOnce(undefined);
    renderDialog({ pending: { email: "new@example.test" }, onConfirm });
    await screen.findByLabelText("Email change code");
    type("Email change code", "123456");
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Wrong email code.",
    );
    expect(screen.getByLabelText("Email change code")).toHaveValue("");
    type("Email change code", "654321");
    expect(
      await screen.findByRole("heading", { name: "Email address changed" }),
    ).toBeInTheDocument();
    expect(onConfirm).toHaveBeenCalledTimes(2);
  });

  it("shows a failure without a field in the dialog's error notice", async () => {
    renderDialog({
      pending: { email: "new@example.test" },
      onConfirm: () => Promise.reject(new Error("Try again in 12 minutes.")),
    });
    await screen.findByLabelText("Email change code");
    type("Email change code", "123456");
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Try again in 12 minutes.",
    );
    expect(screen.getByLabelText("Email change code")).toBeInTheDocument();
  });
});
