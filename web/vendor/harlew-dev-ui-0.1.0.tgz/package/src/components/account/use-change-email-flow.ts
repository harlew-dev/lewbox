import { useState, type FormEvent } from "react";
import { useAction } from "../../lib/use-action";
// The shared change-email workflow: steps, entered factors and the three
// async calls, with no API, router or cache. The app owns those; this hook
// owns only what an opening needs.
export type PendingEmailChange = {
  email: string;
  expiresAt?: string | null;
};
export type ChangeEmailInput = {
  email: string;
  password: string;
  code?: string;
};
export type ChangeEmailProps = {
  open: boolean;
  onClose: () => void;
  // An address already typed elsewhere (account settings' email field): the
  // dialog starts at confirming account access for it and never mentions an
  // earlier request, which confirming replaces. Without one, an earlier
  // request resumes at its code, or a new address is asked for.
  initialEmail?: string;
  // A request already waiting on the server: opening without an initial
  // address resumes at the code it expects.
  pending?: PendingEmailChange | null;
  mfaEnabled: boolean;
  // Whether the server emails a code that must be entered. When false the
  // request finishes the change immediately, so the dialog has no code step
  // and resumes no pending request.
  verification?: boolean;
  onRequest: (input: ChangeEmailInput) => Promise<unknown>;
  onConfirm: (code: string) => Promise<unknown>;
  onCancelChange: () => Promise<unknown>;
  // Runs when the success screen is dismissed, with the new address, before
  // onClose.
  onChanged?: (email: string) => void | Promise<void>;
};
type Step = "destination" | "proof" | "code";
// A request can say it already finished (email verification off), which skips
// the code step in either mode.
function completed(result: unknown): boolean {
  return (
    typeof result === "object" &&
    result !== null &&
    (result as { done?: unknown }).done === true
  );
}
// "done" is the success screen. It stays until the person dismisses it, and
// only then does onChanged run (a page may navigate away from the dialog).
export function useChangeEmailFlow({
  onClose,
  initialEmail,
  pending,
  mfaEnabled,
  verification = true,
  onRequest,
  onConfirm,
  onCancelChange,
  onChanged,
}: ChangeEmailProps) {
  const [step, setStep] = useState<Step | null>(null);
  // Read once per opening: the page may clear its field while this closes.
  const [fresh] = useState(Boolean(initialEmail));
  const [email, setEmail] = useState(
    initialEmail ?? (verification ? pending?.email : undefined) ?? "",
  );
  const [password, setPassword] = useState("");
  const [factor, setFactor] = useState("");
  const [code, setCode] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [changedTo, setChangedTo] = useState<string | null>(null);
  // Cancelling ends on its own screen, with only a Close button.
  const [cancelled, setCancelled] = useState(false);
  const view = changedTo
    ? "done"
    : cancelled
      ? "cancelled"
      : (step ??
        (fresh ? "proof" : verification && pending ? "code" : "destination"));

  function clearSecrets() {
    setPassword("");
    setFactor("");
    setCode("");
  }
  function showError(error: unknown): boolean {
    setPassword("");
    setFactor("");
    const field = (error as { field?: unknown }).field;
    if (typeof field !== "string" || !field) return false;
    const message = error instanceof Error ? error.message : String(error);
    const key =
      field === "currentPassword"
        ? "password"
        : field === "factor"
          ? "code"
          : field;
    setFields({ [key]: message });
    if (key === "email") setStep("destination");
    if (key === "password") setStep("proof");
    if (key === "code") {
      if (view === "code") setCode("");
      else setStep("proof");
    }
    return true;
  }
  const request = useAction(
    async (input: ChangeEmailInput) => {
      setPassword("");
      setFactor("");
      const result = await onRequest(input);
      clearSecrets();
      if (!verification || completed(result)) {
        setChangedTo(input.email.trim());
        return;
      }
      setStep("code");
    },
    { onError: showError },
  );
  const verify = useAction(
    async () => {
      await onConfirm(code);
      clearSecrets();
      setChangedTo(pending?.email ?? email);
    },
    { onError: showError },
  );
  const cancel = useAction(
    async () => {
      await onCancelChange();
      clearSecrets();
      setCancelled(true);
    },
    { onError: showError },
  );
  const finish = useAction(async () => {
    await onChanged?.(changedTo ?? "");
    onClose();
  });
  const busy = request.busy || verify.busy || cancel.busy || finish.busy;
  const loading = request.loading || verify.loading || cancel.loading;

  function resetIssues() {
    setFields({});
    request.clear();
    verify.clear();
    cancel.clear();
  }
  function close() {
    if (busy) return;
    if (changedTo) return void finish.run();
    clearSecrets();
    onClose();
  }
  function resend() {
    if (busy) return;
    if (pending) setEmail(pending.email);
    clearSecrets();
    resetIssues();
    setStep("proof");
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    setFields({});
    if (view === "done") return void finish.run();
    if (view === "cancelled") return;
    if (view === "destination") {
      if (!email.trim()) return;
      setStep("proof");
    } else if (view === "code") {
      if (code.length !== 6) return;
      await verify.run();
    } else {
      if (!password || (mfaEnabled && !factor.trim())) return;
      await request.run(
        mfaEnabled
          ? { email: email.trim(), password, code: factor }
          : { email: email.trim(), password },
      );
    }
  }
  const filled =
    view === "destination"
      ? Boolean(email.trim())
      : view === "proof"
        ? Boolean(password) && (!mfaEnabled || Boolean(factor.trim()))
        : code.length === 6;
  return {
    view,
    pending,
    changedTo,
    finish,
    email,
    setEmail,
    password,
    setPassword,
    factor,
    setFactor,
    code,
    setCode,
    mfaEnabled,
    verification,
    fields,
    busy,
    loading,
    filled,
    request,
    verify,
    cancel,
    submit,
    close,
    resend,
    cancelChange: () => {
      if (!busy) {
        resetIssues();
        void cancel.run();
      }
    },
  };
}
export type ChangeEmailState = ReturnType<typeof useChangeEmailFlow>;
