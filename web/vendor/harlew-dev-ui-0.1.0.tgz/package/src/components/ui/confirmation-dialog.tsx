import type { FormEvent, ReactNode } from "react";
import { useAction } from "../../lib/use-action";
import { Button } from "./button";
import {
  Dialog,
  DialogActions,
  DialogBody,
  DialogDescription,
  DialogTitle,
} from "./dialog";
import { ErrorNotice } from "./feedback";
import { Fieldset } from "./fieldset";
// The confirm button's colour for each variant.
const confirmColors = { danger: "red", default: "dark/zinc" } as const;
type ConfirmationDialogProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  description: string;
  // The confirm button's label, e.g. "Delete project".
  confirm: string;
  // "danger" for destructive actions: a red confirm button.
  variant?: keyof typeof confirmColors;
  // Keeps the confirm button off, e.g. until a name is typed, and why
  // ("Fill in required fields"), shown on the button.
  disabled?: boolean;
  disabledReason?: string;
  onConfirm: () => Promise<unknown>;
  // Runs after the dialog has closed on success (a toast, navigation).
  onConfirmed?: () => unknown;
  // Handles a failure itself (an error on a field); return true to keep it
  // out of the dialog's error notice.
  onError?: (error: unknown) => boolean | void;
  // More to read that isn't a field (the sign-up's word on blocked
  // addresses), below the description.
  body?: ReactNode;
  // Extra fields (type-to-confirm, password), disabled while confirming.
  children?: ReactNode;
};
// Every "are you sure?": a title, what will happen, and Cancel or confirm.
// Confirming runs onConfirm: the button shows loading, a double click
// confirms once, and the dialog can't close until it settles. A failure keeps
// it open, with the error and the typed fields.
export function ConfirmationDialog({
  open,
  onClose,
  title,
  description,
  confirm,
  variant = "default",
  disabled = false,
  disabledReason,
  onConfirm,
  onConfirmed,
  onError,
  body,
  children,
}: ConfirmationDialogProps) {
  const action = useAction(
    async () => {
      await onConfirm();
      onClose();
      await onConfirmed?.();
    },
    { onError },
  );
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (disabled || action.busy) return;
    await action.run();
  }
  const close = () => !action.busy && onClose();
  return (
    <Dialog open={open} onClose={close} size="md">
      <form onSubmit={submit}>
        <DialogTitle>{title}</DialogTitle>
        <DialogDescription>{description}</DialogDescription>
        {action.error.message && (
          <ErrorNotice error={action.error} className="mt-6" />
        )}
        {(body || children) && (
          <DialogBody className="space-y-6">
            {body}
            {children && <Fieldset disabled={action.busy}>{children}</Fieldset>}
          </DialogBody>
        )}
        <DialogActions>
          <Button plain onClick={close} disabled={action.busy}>
            Cancel
          </Button>
          <Button
            type="submit"
            color={confirmColors[variant]}
            loading={action.loading}
            disabled={disabled}
            disabledReason={disabledReason}
          >
            {confirm}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
}
