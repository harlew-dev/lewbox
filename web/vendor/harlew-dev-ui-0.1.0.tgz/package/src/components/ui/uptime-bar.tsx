import { cx } from "../../lib/cx";
import { formatDate } from "../../lib/format";
import { Tooltip } from "./tooltip";

export type UptimeDay = {
  date: string;
  uptime: number | null;
  downMinutes?: number;
};

const levels = {
  up: "bg-green-500",
  degraded: "bg-amber-500",
  down: "bg-red-600 dark:bg-red-500",
  none: "bg-zinc-200 dark:bg-zinc-700",
};

function level(uptime: number | null): keyof typeof levels {
  if (uptime === null) return "none";
  if (uptime >= 0.999) return "up";
  if (uptime >= 0.95) return "degraded";
  return "down";
}

// A share as a percentage, floored to two decimals so any downtime reads
// below 100%: 0.99999 → "99.99%".
export function formatUptime(uptime: number): string {
  const percent = Math.floor(uptime * 10_000 + 1e-9) / 100;
  return `${percent.toLocaleString("en-US", { maximumFractionDigits: 2 })}%`;
}

function formatMinutes(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const rest = Math.round(minutes % 60);
  if (hours === 0) return `${rest}m`;
  return rest === 0 ? `${hours}h` : `${hours}h ${rest}m`;
}

function describe(day: UptimeDay): string {
  const date = formatDate(day.date);
  if (day.uptime === null) return `${date} · No data`;
  const parts = [date, `${formatUptime(day.uptime)} uptime`];
  if (day.downMinutes) parts.push(`${formatMinutes(day.downMinutes)} down`);
  return parts.join(" · ");
}

// A status page's row of days, oldest first: a bar per day coloured by its
// uptime (green, amber, red, grey for no data), its numbers in a tooltip and
// in the list for screen readers, and the period's uptime below.
export function UptimeBar({
  days,
  label = "Uptime",
  uptime,
  className,
}: {
  days: readonly UptimeDay[];
  label?: string;
  uptime?: number | null;
  className?: string;
}) {
  const overall = uptime == null ? undefined : `${formatUptime(uptime)} uptime`;
  const period = days.length === 1 ? "1 day" : `${days.length} days`;
  const summary = [`${label}, last ${period}`, overall].filter(Boolean);
  return (
    <div data-slot="uptime-bar" className={className}>
      <ol aria-label={summary.join(": ")} className="flex h-8 gap-0.5">
        {days.map((day) => {
          const text = describe(day);
          return (
            <Tooltip key={day.date} content={text}>
              <li
                data-level={level(day.uptime)}
                className={cx(
                  "min-w-0 flex-1 rounded-sm hover:opacity-75",
                  levels[level(day.uptime)],
                )}
              >
                <span className="sr-only">{text}</span>
              </li>
            </Tooltip>
          );
        })}
      </ol>
      <div className="mt-2 grid grid-cols-3 text-xs/5 text-zinc-500 dark:text-zinc-400">
        <span>{period} ago</span>
        <span className="text-center tabular-nums">{overall}</span>
        <span className="text-right">Today</span>
      </div>
    </div>
  );
}
