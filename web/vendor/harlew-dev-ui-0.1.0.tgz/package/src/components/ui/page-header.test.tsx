import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ErrorNotice } from "./feedback";
import { PageHeader } from "./page-header";

describe("<PageHeader>", () => {
  it("shows the way back, the title with its badge, and the actions", () => {
    render(
      <PageHeader
        back={{ href: "/clusters", label: "Clusters" }}
        title="EU West"
        meta={<span>Ready</span>}
        description="eu-west"
        actions={<button type="button">Run checks</button>}
      />,
    );
    expect(screen.getByRole("link", { name: "Clusters" })).toHaveAttribute(
      "href",
      "/clusters",
    );
    expect(
      screen.getByRole("heading", { level: 1, name: "EU West" }),
    ).toBeInTheDocument();
    expect(screen.getByText("Ready")).toBeInTheDocument();
    expect(screen.getByText("eu-west")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Run checks" }),
    ).toBeInTheDocument();
  });
});

describe("<ErrorNotice onRetry>", () => {
  it("offers to try again", () => {
    const retry = vi.fn();
    render(
      <ErrorNotice error={{ message: "Could not load.", key: 1 }} onRetry={retry} />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(retry).toHaveBeenCalledOnce();
  });
});

describe("<Steps>", () => {
  it("is an ordered list of titled steps", async () => {
    const { Steps, Step } = await import("./steps");
    render(
      <Steps aria-label="Start a cluster">
        <Step title="Install AerolVM" description="On the machine.">
          <code>lewbox install</code>
        </Step>
        <Step title="Start the cluster" />
      </Steps>,
    );
    const list = screen.getByRole("list", { name: "Start a cluster" });
    expect(list.tagName).toBe("OL");
    expect(screen.getAllByRole("listitem")).toHaveLength(2);
    expect(screen.getByText("Install AerolVM")).toBeInTheDocument();
    expect(screen.getByText("lewbox install")).toBeInTheDocument();
  });
});
