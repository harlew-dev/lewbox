import {
  ArrowLongLeftIcon,
  ArrowLongRightIcon,
} from "@heroicons/react/16/solid";
import { Button } from "./button";
// Older / Newer for cursor lists, which have no page numbers or totals. The
// URL holds `before`, the cursor of the page shown, and a `trail` of the
// earlier cursors (newest first, oldest last) so Newer steps back one page.
// An empty cursor is the newest page, encoded as an empty trail item.
function trailFrom(search: URLSearchParams): string[] {
  const trail = search.get("trail");
  return trail === null ? [] : trail.split(",");
}
function hrefWithTrail(href: string, trail: string[]): string {
  if (trail.length === 0) return href;
  const hashIndex = href.indexOf("#");
  const hash = hashIndex === -1 ? "" : href.slice(hashIndex);
  const base = hashIndex === -1 ? href : href.slice(0, hashIndex);
  const separator = base.includes("?") ? "&" : "?";
  const value = trail.map(encodeURIComponent).join(",");
  return `${base}${separator}trail=${value}${hash}`;
}
export function CursorNav({
  next,
  search,
  hrefFor,
  label,
  reloadDocument,
}: {
  // The next, older page's cursor, or null on the last page.
  next: string | null;
  // The current query, for its `before` and `trail` cursors.
  search: URLSearchParams;
  // The list's URL showing rows older than `before` (undefined: the newest).
  hrefFor: (before: string | undefined) => string;
  label: string;
  reloadDocument?: boolean;
}) {
  const before = search.get("before") ?? "";
  const trail = trailFrom(search);
  const newerHref = trail.length
    ? hrefWithTrail(hrefFor(trail.at(-1) || undefined), trail.slice(0, -1))
    : hrefFor(undefined);
  return (
    <nav aria-label={label} className="mt-6 flex justify-end gap-x-2">
      {before ? (
        <Button plain href={newerHref} reloadDocument={reloadDocument}>
          <ArrowLongLeftIcon />
          Newer
        </Button>
      ) : (
        <Button plain disabled>
          <ArrowLongLeftIcon />
          Newer
        </Button>
      )}
      {next ? (
        <Button
          plain
          href={hrefWithTrail(hrefFor(next), [...trail, before])}
          reloadDocument={reloadDocument}
        >
          Older
          <ArrowLongRightIcon />
        </Button>
      ) : (
        <Button plain disabled>
          Older
          <ArrowLongRightIcon />
        </Button>
      )}
    </nav>
  );
}
