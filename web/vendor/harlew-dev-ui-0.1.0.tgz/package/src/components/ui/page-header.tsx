import type { ReactNode } from "react";
import { ChevronLeftIcon } from "@heroicons/react/16/solid";
import { cx } from "../../lib/cx";
import { Heading } from "./heading";
import { Link } from "./link";
import { Text } from "./text";

// The top of a page, as in Catalyst: an optional link back to the list the
// page belongs to, the title with `meta` beside it (a status badge), a line
// of description under it, and the page's actions on the right of the title
// row (wrapping below it on phones).
export function PageHeader({
  title,
  description,
  meta,
  actions,
  back,
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  // Beside the title: badges, a status.
  meta?: ReactNode;
  // Buttons, or a ⋯ menu, for the whole page.
  actions?: ReactNode;
  // The page above this one: `{ href: "/clusters", label: "Clusters" }`.
  back?: { href: string; label: string };
  className?: string;
}) {
  return (
    <div className={cx(className, "mb-8")}>
      {back && (
        <Link
          href={back.href}
          className="mb-4 inline-flex items-center gap-2 rounded-md text-sm/6 text-zinc-500 data-hover:text-zinc-950 dark:text-zinc-400 dark:data-hover:text-white"
        >
          <ChevronLeftIcon className="size-4 fill-zinc-400 dark:fill-zinc-500" />
          {back.label}
        </Link>
      )}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <Heading className="min-w-0 break-words">{title}</Heading>
            {meta}
          </div>
          {description && <Text className="mt-2">{description}</Text>}
        </div>
        {actions && (
          <div className="flex flex-wrap items-center gap-3">{actions}</div>
        )}
      </div>
    </div>
  );
}
