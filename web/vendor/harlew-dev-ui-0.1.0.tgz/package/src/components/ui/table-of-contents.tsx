import { useEffect, useRef, useState, type ReactNode } from "react";
import { cx } from "../../lib/cx";
import { SideNavItem, SideNavSection } from "./side-nav";

export type TableOfContentsItem = {
  // The heading element's id.
  id: string;
  text: ReactNode;
  // Nested under the previous item (an h3 under its h2).
  nested?: boolean;
};

// The heading whose section is being read: the last one scrolled past the
// top `offset`, or the last of all once the page can't scroll further (a
// short final section never reaches the top).
function currentHeading(items: TableOfContentsItem[], offset: number) {
  const root = document.documentElement;
  if (
    root.scrollHeight > window.innerHeight &&
    window.innerHeight + window.scrollY >= root.scrollHeight - 2
  )
    return items[items.length - 1]?.id ?? null;
  let found = items[0]?.id ?? null;
  for (const item of items) {
    const element = document.getElementById(item.id);
    if (!element) continue;
    if (element.getBoundingClientRect().top > offset) break;
    found = item.id;
  }
  return found;
}

// "On this page": links to a page's headings, beside long content. The
// heading being read is marked as it scrolls, with SideNav's sliding bar.
// `offset` is how far below the top of the window a heading counts as reached
// (a sticky header's height plus a little).
export function TableOfContents({
  items,
  title = "On this page",
  offset = 96,
  className,
}: {
  items: TableOfContentsItem[];
  title?: string;
  offset?: number;
  className?: string;
}) {
  const [current, setCurrent] = useState<string | null>(null);
  // Re-subscribe when the headings change, not when the array is rebuilt.
  const key = items.map((item) => item.id).join("\n");
  const latest = useRef(items);
  latest.current = items;

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setCurrent(currentHeading(latest.current, offset));
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
    };
  }, [key, offset]);

  if (items.length === 0) return null;
  return (
    <nav aria-label={title} className={cx(className)}>
      <SideNavSection title={title}>
        {items.map((item) => (
          // A plain anchor: the browser scrolls to the heading itself, and
          // no router treats the fragment as a page.
          <SideNavItem
            key={item.id}
            href={`#${item.id}`}
            reloadDocument
            nested={item.nested}
            current={item.id === current}
            aria-current="location"
          >
            {item.text}
          </SideNavItem>
        ))}
      </SideNavSection>
    </nav>
  );
}
