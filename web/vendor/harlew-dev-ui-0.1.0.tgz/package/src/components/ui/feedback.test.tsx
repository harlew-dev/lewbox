import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { ErrorNotice, type ActionError } from "./feedback";
describe("error notice", () => {
  it("shows a failure's reference under its message", () => {
    const error: ActionError = {
      message: "Something went wrong. Please try again.",
      key: 1,
      requestId: "req_2yEHYLwiwPVhLW",
    };
    render(<ErrorNotice error={error} />);
    expect(screen.getByRole("alert")).toHaveTextContent(
      "Something went wrong. Please try again.Reference: req_2yEHYLwiwPVhLW",
    );
  });
  it("shows no reference without one", () => {
    const error: ActionError = { message: "Name is taken.", key: 1 };
    render(<ErrorNotice error={error} />);
    expect(screen.getByRole("alert")).toHaveTextContent("Name is taken.");
    expect(screen.queryByText(/Reference/)).toBeNull();
  });
});
