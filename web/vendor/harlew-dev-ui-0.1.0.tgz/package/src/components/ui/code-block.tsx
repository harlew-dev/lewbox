import type { ReactNode } from "react";
import { CheckIcon, DocumentDuplicateIcon } from "@heroicons/react/16/solid";
import { cx } from "../../lib/cx";
import { Clickable } from "./clickable";
import { CopyFailure, useCopy } from "./copy-button";
import { Tooltip } from "./tooltip";

// A block of code, dark in both themes, with a copy button in its corner
// that answers "Copied" like CopyButton. `code` is what gets copied; pass
// `children` to render something richer than the plain text (a
// highlighted or markdown-rendered <code> element).
export function CodeBlock({
  code,
  label = "Copy code",
  className,
  children,
}: {
  code: string;
  label?: string;
  className?: string;
  children?: ReactNode;
}) {
  const copy = useCopy(code);
  return (
    // The block draws the background; the code scrolls in a <pre> that
    // stops short of the copy button's gutter, so a long line never runs
    // under the button.
    <div
      data-slot="code-block"
      className={cx(
        className,
        "relative rounded-xl bg-zinc-950 dark:bg-black/40 dark:ring-1 dark:ring-white/10",
      )}
    >
      <pre className="mr-12 overflow-x-auto py-4 pl-4 text-sm/6 text-zinc-100 [tab-size:2]">
        {children ?? <code>{code}</code>}
      </pre>
      <div className="absolute top-2.5 right-2.5">
        <Tooltip
          content={copy.copied ? <span aria-hidden="true">Copied</span> : "Copy"}
          open={copy.open}
        >
          <Clickable
            aria-label={label}
            onClick={() => void copy.copy()}
            className="flex size-8 items-center justify-center rounded-lg text-zinc-400 data-hover:bg-white/10 data-hover:text-white data-focus:outline-2 data-focus:outline-blue-500 *:size-4 *:fill-current"
          >
            {copy.copied ? <CheckIcon /> : <DocumentDuplicateIcon />}
          </Clickable>
        </Tooltip>
      </div>
      <span role="status" className="sr-only">
        {copy.announced}
      </span>
      <CopyFailure copy={copy} className="mt-2">
        Couldn’t copy. Select the code and copy it instead.
      </CopyFailure>
    </div>
  );
}
