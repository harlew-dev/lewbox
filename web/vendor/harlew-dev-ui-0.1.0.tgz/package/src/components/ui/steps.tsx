import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cx } from "../../lib/cx";

// Steps: numbered instructions to follow in order, such as commands to run
// on a machine. Each Step has a title, an optional line of description and
// its content (a CodeBlock, a field), with a rule joining the numbers.
export function Steps({ className, ...props }: ComponentPropsWithoutRef<"ol">) {
  return (
    <ol
      {...props}
      className={cx(className, "[counter-reset:step] space-y-0")}
    />
  );
}

export function Step({
  title,
  description,
  className,
  children,
}: {
  title: ReactNode;
  description?: ReactNode;
  className?: string;
  children?: ReactNode;
}) {
  return (
    <li
      className={cx(
        className,
        "group/step relative grid grid-cols-[--spacing(7)_minmax(0,1fr)] gap-x-4 pb-8 [counter-increment:step] last:pb-0",
      )}
    >
      {/* The rule from this number down to the next. */}
      <span
        aria-hidden="true"
        className="absolute top-8 bottom-1 left-3.5 w-px -translate-x-1/2 bg-zinc-950/10 group-last/step:hidden dark:bg-white/10"
      />
      <span
        aria-hidden="true"
        className="flex size-7 items-center justify-center rounded-full bg-zinc-950/5 text-xs/6 font-semibold text-zinc-950 tabular-nums ring-1 ring-zinc-950/10 before:content-[counter(step)] dark:bg-white/5 dark:text-white dark:ring-white/10"
      />
      <div className="min-w-0 pt-0.5">
        <div className="text-base/6 font-medium text-zinc-950 sm:text-sm/6 dark:text-white">
          {title}
        </div>
        {description && (
          <div className="mt-1 text-base/6 text-zinc-500 sm:text-sm/6 dark:text-zinc-400">
            {description}
          </div>
        )}
        {children && <div className="mt-3">{children}</div>}
      </div>
    </li>
  );
}
