import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { SideNav, SideNavItem, SideNavSection } from "./side-nav";
import { TableOfContents } from "./table-of-contents";

describe("<SideNav>", () => {
  it("names each section's list by its title and marks the current page", () => {
    render(
      <SideNav aria-label="Documentation">
        <SideNavSection plain>
          <SideNavItem href="/docs">Introduction</SideNavItem>
        </SideNavSection>
        <SideNavSection title="Clusters">
          <SideNavItem href="/docs/start">Start a cluster</SideNavItem>
          <SideNavItem href="/docs/add" current>
            Add nodes
          </SideNavItem>
        </SideNavSection>
      </SideNav>,
    );
    expect(
      screen.getByRole("navigation", { name: "Documentation" }),
    ).toBeInTheDocument();
    const list = screen.getByRole("list", { name: "Clusters" });
    expect(list).toContainElement(
      screen.getByRole("link", { name: "Add nodes" }),
    );
    expect(screen.getByRole("link", { name: "Add nodes" })).toHaveAttribute(
      "aria-current",
      "page",
    );
    expect(
      screen.getByRole("link", { name: "Start a cluster" }),
    ).not.toHaveAttribute("aria-current");
  });
});

describe("<TableOfContents>", () => {
  it("links to each heading as a plain fragment, and marks where the reader is", () => {
    render(
      <>
        <h2 id="install">Install</h2>
        <h3 id="docker">With Docker</h3>
        <TableOfContents
          items={[
            { id: "install", text: "Install" },
            { id: "docker", text: "With Docker", nested: true },
          ]}
        />
      </>,
    );
    const nav = screen.getByRole("navigation", { name: "On this page" });
    expect(nav).toBeInTheDocument();
    const install = screen.getByRole("link", { name: "Install" });
    expect(install).toHaveAttribute("href", "#install");
    // jsdom lays nothing out: every heading is at the top, so the last one
    // reached is the current one.
    expect(screen.getByRole("link", { name: "With Docker" })).toHaveAttribute(
      "aria-current",
      "location",
    );
  });

  it("renders nothing without headings", () => {
    const { container } = render(<TableOfContents items={[]} />);
    expect(container).toBeEmptyDOMElement();
  });
});
