import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Avatar } from "./avatar";
function avatarOf(container: HTMLElement) {
  const avatar = container.querySelector('[data-slot="avatar"]');
  if (!avatar) throw new Error("no avatar");
  return avatar;
}
describe("Avatar", () => {
  it("is square with the dark fill by default", () => {
    const { container } = render(<Avatar initials="AL" />);
    const avatar = avatarOf(container);
    expect(avatar).toHaveClass("rounded-(--avatar-radius)");
    expect(avatar).toHaveClass("bg-zinc-900", "text-white");
    expect(avatar).toHaveClass("dark:bg-white", "dark:text-zinc-950");
  });
  it("is round when square is false", () => {
    const { container } = render(<Avatar initials="AL" square={false} />);
    expect(avatarOf(container)).toHaveClass("rounded-full");
  });
  it("has the soft fill for color='zinc'", () => {
    const { container } = render(<Avatar initials="AL" color="zinc" />);
    const avatar = avatarOf(container);
    expect(avatar).toHaveClass("bg-zinc-100", "text-zinc-600");
    expect(avatar).toHaveClass("dark:bg-zinc-800", "dark:text-zinc-300");
  });
  it("has no fill or text colour for color='none'", () => {
    const { container } = render(<Avatar initials="AL" color="none" />);
    expect(avatarOf(container).className).not.toMatch(/(^|\s)bg-/);
    expect(avatarOf(container).className).not.toMatch(/(^|\s)text-(white|zinc)/);
  });
});
