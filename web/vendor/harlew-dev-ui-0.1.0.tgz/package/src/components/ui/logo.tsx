import type { ReactNode } from "react";
import { cx } from "../../lib/cx";
import { Link } from "./link";

// Wordmark: a small graph of linked nodes and the app name. Inherits text
// colour. `mark` replaces the default graph; with `href` the wordmark is a
// link (e.g. to the homepage), named by `name`.
function DefaultMark() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="size-6 fill-current stroke-current"
      aria-hidden="true"
    >
      <path
        d="M4.5 9 11 4l2 8.5L4.5 9M13 12.5l7-3M13 12.5 7.5 19M13 12.5l6 7"
        fill="none"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="13" cy="12.5" r="3" />
      <circle cx="4.5" cy="9" r="2" />
      <circle cx="11" cy="4" r="2.25" />
      <circle cx="20" cy="9.5" r="1.75" />
      <circle cx="7.5" cy="19" r="2.25" />
      <circle cx="19" cy="19.5" r="1.75" />
    </svg>
  );
}

export function Logo({
  name,
  mark,
  className,
  href,
  reloadDocument,
}: {
  name: string;
  // Replaces the default graph, before the name.
  mark?: ReactNode;
  className?: string;
  href?: string;
  reloadDocument?: boolean;
}) {
  const classes = cx(
    className,
    "inline-flex items-center gap-2 text-zinc-950 dark:text-white",
  );
  const content = (
    <>
      {mark ?? <DefaultMark />}
      <span className="text-lg/6 font-semibold tracking-tight">{name}</span>
    </>
  );
  if (href === undefined) return <span className={classes}>{content}</span>;
  // w-fit: in a grid or flex column, only the wordmark itself is clickable.
  return (
    <Link
      href={href}
      reloadDocument={reloadDocument}
      className={cx(classes, "w-fit rounded-md")}
    >
      {content}
    </Link>
  );
}
