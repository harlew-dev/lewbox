import type { ReactNode } from "react";
import { cx } from "../../lib/cx";
import { CopyButton, CopyFailure, useCopy } from "./copy-button";

// A value someone pastes elsewhere (an ID, a URL), in monospace and
// truncated to fit, with a copy button beside it. `children` replaces the
// shown text (a shortened ID); the full `value` is what's copied.
export function CopyText({
  value,
  label = "Copy",
  children,
  className,
}: {
  value: string;
  label?: string;
  children?: ReactNode;
  className?: string;
}) {
  const copy = useCopy(value);
  return (
    <div data-slot="copy-text" className={cx(className, "min-w-0")}>
      <div className="flex min-w-0 items-center gap-1">
        <span
          title={value}
          className="min-w-0 truncate font-mono text-sm/6 text-zinc-950 dark:text-white"
        >
          {children ?? value}
        </span>
        <CopyButton copy={copy} label={label} />
      </div>
      <CopyFailure copy={copy} className="mt-1">
        Couldn’t copy. Select the text and copy it instead.
      </CopyFailure>
    </div>
  );
}
