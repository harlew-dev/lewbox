import {
  createContext,
  useContext,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type ComponentPropsWithoutRef,
  type PointerEvent,
  type ReactNode,
} from "react";
import { motion, useReducedMotion } from "motion/react";
import { cx } from "../../lib/cx";
import { Clickable } from "./clickable";
import { highlightTransition } from "./highlight";

// SideNav: the page list beside a documentation or settings page, as in the
// Catalyst docs. Sections are lists on a thin rule; the current page is a bar
// on the rule, and a fainter bar follows the mouse. Both slide between items
// with the sidebar's spring. A `plain` section has no rule, for a few
// top-level links with icons ("Getting started").
//
// The bars are positioned from the items' offsets inside their list, not
// with layout animations, so scrolling the page (or the sticky column the nav
// sits in) between two renders never shifts where they slide from.
export function SideNav({
  className,
  ...props
}: ComponentPropsWithoutRef<"nav">) {
  return <nav {...props} className={cx(className, "flex flex-col gap-8")} />;
}

export function SideNavHeading({
  className,
  ...props
}: ComponentPropsWithoutRef<"h3">) {
  return (
    <h3
      {...props}
      className={cx(
        className,
        "text-base/6 font-medium text-zinc-950 sm:text-sm/6 dark:text-white",
      )}
    />
  );
}

const PlainContext = createContext(false);

type Box = { top: number; height: number };

function sameBox(a: Box | null, b: Box | null) {
  return a === b || (!!a && !!b && a.top === b.top && a.height === b.height);
}

// Where an item's bar goes: its text line, not the padding around it.
function barBox(item: HTMLElement): Box {
  return { top: item.offsetTop + 6, height: item.offsetHeight - 12 };
}

// The item (li) under an event in this list, if any.
function itemAt(list: HTMLElement, target: EventTarget | null) {
  if (!(target instanceof Element)) return null;
  const item = target.closest("li");
  return item && item.parentElement === list ? item : null;
}

export function SideNavSection({
  title,
  plain = false,
  className,
  children,
  ...props
}: {
  // Shown above the list, and names it.
  title?: ReactNode;
  // No rule and no bars: icon links, such as a home link above the sections.
  plain?: boolean;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<"div">, "title" | "children">) {
  const headingId = useId();
  const list = useRef<HTMLUListElement>(null);
  const [current, setCurrent] = useState<Box | null>(null);
  const [hover, setHover] = useState<Box | null>(null);
  const reduceMotion = useReducedMotion();
  const transition = reduceMotion ? { duration: 0 } : highlightTransition;

  // Measured after every render (the current page, or the items, may have
  // changed) and whenever the list resizes (a label wraps).
  useLayoutEffect(() => {
    const element = list.current;
    if (plain || !element) return;
    const measure = () => {
      const link = element.querySelector<HTMLElement>(
        ":scope > li > [data-current]",
      );
      const next = link?.parentElement ? barBox(link.parentElement) : null;
      setCurrent((previous) => (sameBox(previous, next) ? previous : next));
    };
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  });

  function trackHover(event: PointerEvent<HTMLUListElement>) {
    if (plain || event.pointerType !== "mouse") return;
    const item = itemAt(event.currentTarget, event.target);
    if (!item) return;
    const next = barBox(item);
    setHover((previous) => (sameBox(previous, next) ? previous : next));
  }

  return (
    <div {...props} data-slot="section" className={className}>
      {title && <SideNavHeading id={headingId}>{title}</SideNavHeading>}
      <ul
        ref={list}
        role="list"
        aria-labelledby={title ? headingId : undefined}
        onPointerOver={trackHover}
        onPointerLeave={() => setHover(null)}
        className={cx(
          "relative",
          title != null && "mt-3",
          !plain && "border-l border-zinc-950/10 dark:border-white/10",
        )}
      >
        {/* Mounting with initial={false} puts a bar straight where it
            belongs; only a move between items slides. */}
        {hover && (
          <motion.span
            aria-hidden="true"
            initial={false}
            animate={{ y: hover.top, height: hover.height }}
            transition={transition}
            className="pointer-events-none absolute top-0 -left-px w-px bg-zinc-400 forced-colors:hidden dark:bg-zinc-500"
          />
        )}
        {current && (
          <motion.span
            aria-hidden="true"
            initial={false}
            animate={{ y: current.top, height: current.height }}
            transition={transition}
            className="pointer-events-none absolute top-0 -left-[1.5px] w-0.5 rounded-full bg-zinc-950 forced-colors:bg-[Highlight] dark:bg-white"
          />
        )}
        <PlainContext.Provider value={plain}>{children}</PlainContext.Provider>
      </ul>
    </div>
  );
}

const ruledItemClasses = cx(
  "flex items-center gap-2 py-1.5 pr-2 text-base/6 font-medium sm:text-sm/6",
  "text-zinc-600 data-current:text-zinc-950 data-hover:text-zinc-950",
  "dark:text-zinc-400 dark:data-current:text-white dark:data-hover:text-white",
);

const plainItemClasses = cx(
  "flex items-center gap-3 py-1.5 pr-2 text-base/6 font-medium sm:text-sm/6",
  "text-zinc-600 data-current:text-zinc-950 data-hover:text-zinc-950",
  "dark:text-zinc-400 dark:data-current:text-white dark:data-hover:text-white",
  // Leading icon
  "*:data-[slot=icon]:size-5 *:data-[slot=icon]:shrink-0 *:data-[slot=icon]:fill-zinc-400",
  "data-current:*:data-[slot=icon]:fill-zinc-950 data-hover:*:data-[slot=icon]:fill-zinc-950",
  "dark:*:data-[slot=icon]:fill-zinc-500 dark:data-current:*:data-[slot=icon]:fill-white dark:data-hover:*:data-[slot=icon]:fill-white",
);

// One link in a SideNavSection. `current` marks the page being shown
// (`aria-current="page"`, or another value through `aria-current`, such as
// "location" for a heading). `nested` indents it under the item above (an h3
// under its h2).
export function SideNavItem({
  current,
  nested,
  "aria-current": ariaCurrent = "page",
  className,
  children,
  ...props
}: {
  href: string;
  reloadDocument?: boolean;
  current?: boolean;
  nested?: boolean;
  className?: string;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<"a">, "href" | "className">) {
  const plain = useContext(PlainContext);
  return (
    <li className={className}>
      <Clickable
        {...props}
        aria-current={current ? ariaCurrent : undefined}
        data-current={current ? "" : undefined}
        className={cx(
          plain ? plainItemClasses : ruledItemClasses,
          !plain && (nested ? "pl-8" : "pl-4"),
        )}
      >
        {children}
      </Clickable>
    </li>
  );
}
