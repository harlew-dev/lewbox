import {
  createContext,
  forwardRef,
  useContext,
  type AnchorHTMLAttributes,
  type ComponentType,
  type ForwardRefExoticComponent,
  type ReactNode,
  type RefAttributes,
} from "react";
import { useInteractive } from "../../lib/interactive";

export type LinkProps = Omit<
  AnchorHTMLAttributes<HTMLAnchorElement>,
  "href"
> & {
  href: string;
  // Leave the app's link provider for a real page load.
  reloadDocument?: boolean;
};

const schemePattern = /^([a-z][a-z\d+.-]*):/i;

// Whether a link must be a plain <a>: it asks for a full page load, uses a
// non-http(s) scheme, points at another origin, or asks the browser to open a
// new context or download. Everything else can go through LinkProvider.
export function isNativeLink(
  href: string,
  {
    target,
    download,
    reloadDocument,
  }: {
    target?: string;
    download?: unknown;
    reloadDocument?: boolean;
  } = {},
): boolean {
  if (reloadDocument) return true;
  if (target !== undefined && target.toLowerCase() !== "_self") return true;
  if (download !== undefined && download !== false) return true;
  const scheme = href.match(schemePattern)?.[1]?.toLowerCase();
  if (scheme && scheme !== "http" && scheme !== "https") return true;
  if (scheme === "http" || scheme === "https" || href.startsWith("//")) {
    if (typeof window === "undefined") return true;
    try {
      return (
        new URL(href, window.location.href).origin !== window.location.origin
      );
    } catch {
      return true;
    }
  }
  return false;
}

// A link component that renders an anchor and accepts LinkProps (for example
// a router's Link, wrapped to map `href` to its own prop). A forwardRef
// component is assignable to this.
export type LinkComponent = ComponentType<LinkProps>;

const LinkContext = createContext<LinkComponent | null>(null);

// Wrap an app once to route every Link (including Button, Clickable and
// TextLink) through a client-side navigation component. Without a provider,
// Link renders a plain <a>.
export function LinkProvider({
  component,
  children,
}: {
  component: LinkComponent;
  children: ReactNode;
}) {
  return (
    <LinkContext.Provider value={component}>{children}</LinkContext.Provider>
  );
}

// A link that exposes data-hover/active/focus for the Tailwind styles. It
// renders the app's link component when one is provided, except for native
// links (see isNativeLink), which stay plain <a> elements.
export const Link = forwardRef<HTMLAnchorElement, LinkProps>(function Link(
  { href, reloadDocument, ...props },
  ref,
) {
  const Component = useContext(LinkContext);
  const interactive = useInteractive<HTMLAnchorElement>(props);
  const native = isNativeLink(href, {
    target: props.target,
    download: props.download,
    reloadDocument,
  });
  if (Component && !native) {
    const Routed = Component as ForwardRefExoticComponent<
      LinkProps & RefAttributes<HTMLAnchorElement>
    >;
    return <Routed ref={ref} href={href} {...props} {...interactive} />;
  }
  return <a ref={ref} href={href} {...props} {...interactive} />;
});
