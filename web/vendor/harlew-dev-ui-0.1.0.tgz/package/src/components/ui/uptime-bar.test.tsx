import { render, screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { formatUptime, UptimeBar } from "./uptime-bar";
import { hover } from "../../../tests/hover";

const days = [
  { date: "2026-11-01", uptime: 0.9931, downMinutes: 12 },
  { date: "2026-11-02", uptime: 1 },
  { date: "2026-11-03", uptime: 0.96, downMinutes: 125 },
  { date: "2026-11-04", uptime: 0.5, downMinutes: 720 },
  { date: "2026-11-05", uptime: null },
];

describe("formatUptime", () => {
  it("floors to two decimals so any downtime is below 100%", () => {
    expect(formatUptime(1)).toBe("100%");
    expect(formatUptime(0.99999)).toBe("99.99%");
    expect(formatUptime(0.9995)).toBe("99.95%");
    expect(formatUptime(0.9931)).toBe("99.31%");
    expect(formatUptime(0.999)).toBe("99.9%");
    expect(formatUptime(0)).toBe("0%");
  });
});

describe("UptimeBar", () => {
  it("lists a day per bar, coloured by its uptime, with its numbers", () => {
    render(<UptimeBar label="eu-west" days={days} uptime={0.99951} />);
    const list = screen.getByRole("list", {
      name: "eu-west, last 5 days: 99.95% uptime",
    });
    const bars = within(list).getAllByRole("listitem");
    expect(bars.map((bar) => bar.textContent)).toEqual([
      "Nov 1 · 99.31% uptime · 12m down",
      "Nov 2 · 100% uptime",
      "Nov 3 · 96% uptime · 2h 5m down",
      "Nov 4 · 50% uptime · 12h down",
      "Nov 5 · No data",
    ]);
    expect(bars.map((bar) => bar.dataset.level)).toEqual([
      "degraded",
      "up",
      "degraded",
      "down",
      "none",
    ]);
    expect(bars[1]).toHaveClass("bg-green-500");
    expect(bars[0]).toHaveClass("bg-amber-500");
    expect(bars[3]).toHaveClass("bg-red-600");
    expect(bars[4]).toHaveClass("bg-zinc-200");
  });

  it("colours at the thresholds", () => {
    render(
      <UptimeBar
        days={[
          { date: "2026-11-01", uptime: 0.999 },
          { date: "2026-11-02", uptime: 0.9989 },
          { date: "2026-11-03", uptime: 0.95 },
          { date: "2026-11-04", uptime: 0.9499 },
        ]}
      />,
    );
    expect(
      screen.getAllByRole("listitem").map((bar) => bar.dataset.level),
    ).toEqual(["up", "degraded", "degraded", "down"]);
  });

  it("shows a day's numbers in a tooltip", async () => {
    render(<UptimeBar days={days} />);
    hover(screen.getAllByRole("listitem")[0]);
    expect(await screen.findByRole("tooltip")).toHaveTextContent(
      "Nov 1 · 99.31% uptime · 12m down",
    );
  });

  it("labels the period below the bars", () => {
    render(<UptimeBar days={days} uptime={0.99999} />);
    expect(screen.getByRole("list")).toHaveAccessibleName(
      "Uptime, last 5 days: 99.99% uptime",
    );
    expect(screen.getByText("5 days ago")).toBeInTheDocument();
    expect(screen.getByText("99.99% uptime")).toBeInTheDocument();
    expect(screen.getByText("Today")).toBeInTheDocument();
  });

  it("leaves the overall uptime out when it isn't given", () => {
    render(<UptimeBar days={days.slice(0, 1)} />);
    expect(screen.getByRole("list")).toHaveAccessibleName("Uptime, last 1 day");
    expect(screen.getByText("1 day ago")).toBeInTheDocument();
    expect(screen.queryByText(/% uptime$/)).toBeNull();
  });
});
