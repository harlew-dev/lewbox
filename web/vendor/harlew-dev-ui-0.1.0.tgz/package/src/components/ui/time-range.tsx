import { Listbox, ListboxLabel, ListboxOption } from "./listbox";
// The time range of a log: a Listbox of presets and "Custom range…", which
// the page opens in a RangeDialog. A custom range shows as its own value
// (and is chosen again to change it). The admin dashboard's Events and a
// project's Logs share it.
export function TimeRange<T extends string>({
  value,
  presets,
  custom,
  onPreset,
  onCustom,
  className = "sm:w-60",
  "aria-label": ariaLabel = "Time range",
}: {
  // The preset in use, ignored while `custom` is set.
  value: T;
  presets: readonly { id: T; label: string }[];
  // The custom range's label when one is applied, else null.
  custom: string | null;
  onPreset: (preset: T) => void;
  onCustom: () => void;
  className?: string;
  // The control's accessible name ("Time range", or "Date" in a filter form).
  "aria-label"?: string;
}) {
  return (
    <Listbox<string>
      aria-label={ariaLabel}
      value={custom ? "custom" : value}
      onChange={(v) => (v === "custom" ? onCustom() : onPreset(v as T))}
      className={className}
    >
      {presets.map((preset) => (
        <ListboxOption key={preset.id} value={preset.id}>
          <ListboxLabel>{preset.label}</ListboxLabel>
        </ListboxOption>
      ))}
      <ListboxOption value="custom">
        <ListboxLabel>{custom ?? "Custom range…"}</ListboxLabel>
      </ListboxOption>
    </Listbox>
  );
}
