import type { ReactNode } from "react";
import { cx } from "../../lib/cx";

// Who someone is, in one line: an avatar, then their name with a second line
// under it (an email, a role). Both lines truncate. Catalyst's sidebar footer
// uses it as the account menu's button: put it in a SidebarItem or
// NavbarItem with a chevron after it.
export function UserIdentity({
  avatar,
  name,
  detail,
  className,
}: {
  // An Avatar, sized by the caller (size-10 in a sidebar footer).
  avatar?: ReactNode;
  name: ReactNode;
  detail?: ReactNode;
  className?: string;
}) {
  return (
    <span className={cx(className, "flex min-w-0 items-center gap-3")}>
      {avatar}
      <span className="min-w-0 text-left">
        <span className="block truncate text-sm/5 font-medium text-zinc-950 dark:text-white">
          {name}
        </span>
        {detail && (
          <span className="block truncate text-xs/5 font-normal text-zinc-500 dark:text-zinc-400">
            {detail}
          </span>
        )}
      </span>
    </span>
  );
}
