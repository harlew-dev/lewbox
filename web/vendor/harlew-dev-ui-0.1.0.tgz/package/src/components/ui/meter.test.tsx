import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Meter } from "./chart";
describe("Meter", () => {
  it("fills to its share of max", () => {
    render(<Meter label="Sandboxes" value={1} max={4} valueText="1 of 4" />);
    const meter = screen.getByRole("meter", { name: "Sandboxes" });
    expect(meter).toHaveAttribute("aria-valuemax", "4");
    expect(meter).toHaveAttribute("aria-valuenow", "1");
    expect(meter).toHaveAttribute("aria-valuetext", "1 of 4");
    expect(meter.firstElementChild).toHaveStyle({ "--share": "25%" });
  });
  it("shows an empty track with no max when there is no limit", () => {
    render(
      <Meter label="vCPUs" value={3} max={null} valueText="3 · Unlimited" />,
    );
    const meter = screen.getByRole("meter", { name: "vCPUs" });
    expect(meter).not.toHaveAttribute("aria-valuemax");
    expect(meter).toHaveAttribute("aria-valuenow", "3");
    expect(meter).toHaveAttribute("aria-valuetext", "3 · Unlimited");
    expect(meter.firstElementChild).toBeNull();
  });
});
