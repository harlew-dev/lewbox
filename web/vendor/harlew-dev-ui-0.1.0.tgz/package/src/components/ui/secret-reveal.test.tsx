import { act, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { SecretReveal } from "./secret-reveal";
afterEach(() => {
  vi.unstubAllGlobals();
});
describe("SecretReveal", () => {
  it("shows the secret once, copies it, and keeps the extras below", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    vi.stubGlobal("navigator", { clipboard: { writeText } });
    render(
      <SecretReveal secret="lba_0123456789" label="Copy API key">
        <p>Use it like this.</p>
      </SecretReveal>,
    );
    expect(screen.getByText("lba_0123456789")).toHaveClass("font-mono");
    expect(
      screen.getByText("Copy it now. You won’t see it again."),
    ).toBeInTheDocument();
    expect(screen.getByText("Use it like this.")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Copy API key" }));
    await act(async () => {
      await Promise.resolve();
    });
    expect(writeText).toHaveBeenCalledWith("lba_0123456789");
  });
  it("labels the copy button for a secret by default", () => {
    render(<SecretReveal secret="s3cret" />);
    expect(screen.getByRole("button", { name: "Copy secret" })).toBeInTheDocument();
  });
});
