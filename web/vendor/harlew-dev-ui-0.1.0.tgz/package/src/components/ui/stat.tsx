import type { ReactNode } from "react";
import { LevelBadge, type Level } from "./badge";
import { Divider } from "./divider";
import { Link } from "./link";
// A headline number under a rule: its title, the value ("–" until it has
// loaded), and a line of context below. For monitoring, it can also carry a
// level (a LevelBadge beside the title: the word, never colour alone), link
// its title to the page behind it, and show a chart (a Sparkline) under the
// value.
export function Stat({
  title,
  value,
  level,
  href,
  reloadDocument,
  chart,
  children,
}: {
  title: string;
  value: ReactNode | undefined;
  level?: Level;
  href?: string;
  reloadDocument?: boolean;
  chart?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div>
      <Divider />
      <div className="mt-6 flex items-center justify-between gap-2">
        <div className="text-lg/6 font-medium text-zinc-950 sm:text-sm/6 dark:text-white">
          {href ? (
            <Link
              href={href}
              reloadDocument={reloadDocument}
              className="data-focus:outline-2 data-focus:outline-blue-500 data-hover:underline"
            >
              {title}
            </Link>
          ) : (
            title
          )}
        </div>
        {level && <LevelBadge level={level} />}
      </div>
      <div className="mt-3 text-3xl/8 font-semibold text-zinc-950 tabular-nums sm:text-2xl/8 dark:text-white">
        {value ?? "–"}
      </div>
      {chart && <div className="mt-3">{chart}</div>}
      {children && (
        <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm/6 text-zinc-500 sm:text-xs/6 dark:text-zinc-400">
          {children}
        </div>
      )}
    </div>
  );
}
