import { Navbar, NavbarItem, NavbarSection } from "./navbar";
// Tabs of one page, kept in its `?tab=` (the first tab has none), so back
// and forward walk through them and a link opens one. The app passes the
// current tab from its URL. Choosing a tab drops the other parameters: each
// tab has its own filters.
export function PageTabs<T extends string>({
  label,
  tabs,
  current,
  reloadDocument,
  className = "mt-4",
}: {
  label: string;
  tabs: readonly { id: T; label: string }[];
  current: T;
  reloadDocument?: boolean;
  className?: string;
}) {
  const hrefFor = (id: T) => (id === tabs[0].id ? "?" : `?tab=${id}`);
  return (
    <Navbar aria-label={label} className={className}>
      <NavbarSection className="-ml-2">
        {tabs.map((tab) => (
          <NavbarItem
            key={tab.id}
            href={hrefFor(tab.id)}
            reloadDocument={reloadDocument}
            current={tab.id === current}
            aria-current={tab.id === current ? "page" : undefined}
          >
            {tab.label}
          </NavbarItem>
        ))}
      </NavbarSection>
    </Navbar>
  );
}

// The tab named by a query string, or the first when it names none of `tabs`.
export function tabFrom<T extends string>(
  search: URLSearchParams,
  tabs: readonly { id: T }[],
): T {
  const tab = search.get("tab");
  return tabs.find((candidate) => candidate.id === tab)?.id ?? tabs[0].id;
}
