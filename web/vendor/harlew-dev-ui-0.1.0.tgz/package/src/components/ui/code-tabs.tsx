import { Tabs } from "@base-ui/react/tabs";
import { CodeBlock } from "./code-block";

export type CodeTab = { label: string; language?: string; code: string };

// The same snippet in several forms (a CLI command, curl, an SDK): a tab per
// form above a CodeBlock with its copy button. Arrow keys move between tabs.
// `language` is set as the code's `language-*` class, for a highlighter.
export function CodeTabs({
  tabs,
  label = "Code examples",
  className,
}: {
  tabs: readonly CodeTab[];
  label?: string;
  className?: string;
}) {
  return (
    <Tabs.Root defaultValue={0} data-slot="code-tabs" className={className}>
      <Tabs.List aria-label={label} className="flex flex-wrap gap-1">
        {tabs.map((tab, index) => (
          <Tabs.Tab
            key={index}
            value={index}
            className="rounded-md px-2.5 py-1 text-sm/6 font-medium text-zinc-500 hover:text-zinc-950 focus-visible:outline-2 focus-visible:outline-blue-500 data-active:bg-zinc-950/5 data-active:text-zinc-950 dark:text-zinc-400 dark:hover:text-white dark:data-active:bg-white/10 dark:data-active:text-white"
          >
            {tab.label}
          </Tabs.Tab>
        ))}
      </Tabs.List>
      {tabs.map((tab, index) => (
        <Tabs.Panel
          key={index}
          value={index}
          className="mt-2 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500"
        >
          <CodeBlock code={tab.code} label={`Copy ${tab.label} code`}>
            <code
              className={tab.language ? `language-${tab.language}` : undefined}
            >
              {tab.code}
            </code>
          </CodeBlock>
        </Tabs.Panel>
      ))}
    </Tabs.Root>
  );
}
