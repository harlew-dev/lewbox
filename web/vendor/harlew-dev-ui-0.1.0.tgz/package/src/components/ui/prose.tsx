import type { ComponentPropsWithoutRef } from "react";
import { cx } from "../../lib/cx";

// Long-form text whose elements come without classes: rendered markdown,
// documentation, a changelog. The library has no typography plugin, so this
// styles the elements such content uses, in the zinc palette, light and dark.
// Headings get a scroll margin for a sticky header (DocsLayout's is 4rem).
// Code blocks are dark in both themes.
const proseClasses = cx(
  "text-base/7 text-zinc-700 dark:text-zinc-300",
  "*:first:mt-0",
  // Headings
  "[&_:is(h2,h3,h4)]:scroll-mt-24 [&_:is(h2,h3,h4)]:font-semibold [&_:is(h2,h3,h4)]:tracking-tight [&_:is(h2,h3,h4)]:text-zinc-950 dark:[&_:is(h2,h3,h4)]:text-white",
  "[&_h2]:mt-12 [&_h2]:mb-4 [&_h2]:text-xl/7",
  "[&_h3]:mt-8 [&_h3]:mb-3 [&_h3]:text-lg/7",
  "[&_h4]:mt-6 [&_h4]:mb-2 [&_h4]:text-base/7",
  // Blocks
  // A CodeBlock is spaced as a whole; its own <pre> sits flush in it.
  "[&_:is(p,ul,ol,blockquote,table,[data-slot=code-block])]:my-5 [&_:not([data-slot=code-block])>pre]:my-5",
  "[&_:is(ul,ol)]:pl-6 [&_ul]:list-disc [&_ol]:list-decimal [&_li]:my-1.5 [&_li]:pl-1",
  "[&_li>:is(ul,ol)]:my-1.5 [&_li::marker]:text-zinc-400 dark:[&_li::marker]:text-zinc-500",
  "[&_blockquote]:border-l-2 [&_blockquote]:border-zinc-950/10 [&_blockquote]:pl-4 [&_blockquote]:text-zinc-600 dark:[&_blockquote]:border-white/15 dark:[&_blockquote]:text-zinc-400",
  "[&_hr]:my-10 [&_hr]:border-zinc-950/10 dark:[&_hr]:border-white/10",
  // Inline
  "[&_a]:font-medium [&_a]:text-zinc-950 [&_a]:underline [&_a]:decoration-zinc-950/30 [&_a]:underline-offset-2 [&_a:hover]:decoration-zinc-950 dark:[&_a]:text-white dark:[&_a]:decoration-white/30 dark:[&_a:hover]:decoration-white",
  // A link in a heading (its permalink) reads as the heading, not a link.
  "[&_:is(h2,h3,h4)_a]:font-[inherit] [&_:is(h2,h3,h4)_a]:no-underline",
  "[&_strong]:font-semibold [&_strong]:text-zinc-950 dark:[&_strong]:text-white",
  "[&_:not(pre)>code]:rounded-md [&_:not(pre)>code]:bg-zinc-950/5 [&_:not(pre)>code]:px-1.5 [&_:not(pre)>code]:py-0.5 [&_:not(pre)>code]:text-[0.875em] [&_:not(pre)>code]:font-medium [&_:not(pre)>code]:text-zinc-950",
  "dark:[&_:not(pre)>code]:bg-white/10 dark:[&_:not(pre)>code]:text-white",
  // Tables
  "[&_table]:w-full [&_table]:border-collapse [&_table]:text-sm/6",
  "[&_th]:border-b [&_th]:border-zinc-950/10 [&_th]:px-3 [&_th]:py-2 [&_th]:text-left [&_th]:font-semibold [&_th]:text-zinc-950 dark:[&_th]:border-white/10 dark:[&_th]:text-white",
  "[&_td]:border-b [&_td]:border-zinc-950/5 [&_td]:px-3 [&_td]:py-2 [&_td]:align-top dark:[&_td]:border-white/5",
  "[&_:is(th,td):first-child]:pl-0",
  // Code blocks: a bare <pre>. A CodeBlock styles its own.
  "[&_:not([data-slot=code-block])>pre]:overflow-x-auto [&_:not([data-slot=code-block])>pre]:rounded-xl [&_:not([data-slot=code-block])>pre]:bg-zinc-950 [&_:not([data-slot=code-block])>pre]:p-4 [&_:not([data-slot=code-block])>pre]:text-sm/6 [&_:not([data-slot=code-block])>pre]:text-zinc-100",
  "dark:[&_:not([data-slot=code-block])>pre]:bg-black/40 dark:[&_:not([data-slot=code-block])>pre]:ring-1 dark:[&_:not([data-slot=code-block])>pre]:ring-white/10",
  "[&_pre_code]:bg-transparent [&_pre_code]:p-0 [&_pre_code]:text-inherit",
);

export function Prose({
  className,
  ...props
}: ComponentPropsWithoutRef<"div">) {
  return <div {...props} className={cx(className, proseClasses)} />;
}
