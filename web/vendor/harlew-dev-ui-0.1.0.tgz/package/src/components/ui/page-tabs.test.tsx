import { describe, expect, it } from "vitest";
import { tabFrom } from "./page-tabs";

const tabs = [{ id: "overview" }, { id: "activity" }] as const;

describe("tabFrom", () => {
  it("returns the tab named by ?tab=", () => {
    expect(tabFrom(new URLSearchParams("tab=activity"), tabs)).toBe("activity");
  });
  it("returns the first tab when ?tab= names none", () => {
    expect(tabFrom(new URLSearchParams("tab=missing"), tabs)).toBe("overview");
    expect(tabFrom(new URLSearchParams(), tabs)).toBe("overview");
  });
});
