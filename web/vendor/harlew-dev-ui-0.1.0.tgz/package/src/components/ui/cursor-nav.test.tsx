import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CursorNav } from "./cursor-nav";

function hrefFor(before: string | undefined) {
  return before ? `/items?before=${encodeURIComponent(before)}` : "/items";
}

function renderNav(search: URLSearchParams, next: string | null) {
  return render(
    <CursorNav
      next={next}
      search={search}
      hrefFor={hrefFor}
      label="Items"
    />,
  );
}

function newerHref() {
  return screen.getByRole("link", { name: "Newer" }).getAttribute("href");
}

function olderHref() {
  return screen.getByRole("link", { name: "Older" }).getAttribute("href");
}

describe("<CursorNav>", () => {
  it("walking Older twice then Newer twice steps back one page at a time", () => {
    const { rerender } = renderNav(new URLSearchParams(), "c2");
    expect(olderHref()).toBe("/items?before=c2&trail=");

    rerender(
      <CursorNav
        next="c3"
        search={new URLSearchParams("before=c2&trail=")}
        hrefFor={hrefFor}
        label="Items"
      />,
    );
    expect(olderHref()).toBe("/items?before=c3&trail=,c2");

    rerender(
      <CursorNav
        next="c4"
        search={new URLSearchParams("before=c3&trail=,c2")}
        hrefFor={hrefFor}
        label="Items"
      />,
    );
    expect(newerHref()).toBe("/items?before=c2&trail=");

    rerender(
      <CursorNav
        next="c3"
        search={new URLSearchParams("before=c2&trail=")}
        hrefFor={hrefFor}
        label="Items"
      />,
    );
    expect(newerHref()).toBe("/items");
  });
  it("opens without a trail and sends Newer to the newest page", () => {
    renderNav(new URLSearchParams("before=c2"), "c3");
    expect(newerHref()).toBe("/items");
  });
});
