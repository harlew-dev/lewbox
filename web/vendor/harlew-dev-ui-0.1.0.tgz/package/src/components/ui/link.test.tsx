import { forwardRef, type ReactNode } from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { Button } from "./button";
import {
  isNativeLink,
  Link,
  LinkProvider,
  type LinkProps,
} from "./link";

const FakeLink = forwardRef<HTMLAnchorElement, LinkProps>(function FakeLink(
  { href, ...props },
  ref,
) {
  return <a ref={ref} href={href} data-fake-link="" {...props} />;
});

function renderWithProvider(node: ReactNode) {
  return render(<LinkProvider component={FakeLink}>{node}</LinkProvider>);
}

describe("<Link>", () => {
  it("renders a plain anchor by default", () => {
    render(<Link href="/next">Next</Link>);
    const link = screen.getByRole("link", { name: "Next" });
    expect(link).toHaveAttribute("href", "/next");
    expect(link).not.toHaveAttribute("data-fake-link");
  });
  it("renders the provider's component with the href and children", () => {
    renderWithProvider(<Link href="/next">Next</Link>);
    const link = screen.getByRole("link", { name: "Next" });
    expect(link).toHaveAttribute("href", "/next");
    expect(link).toHaveAttribute("data-fake-link");
  });
  it("keeps the provider for a same-origin absolute href", () => {
    renderWithProvider(
      <Link href={`${window.location.origin}/next`}>Next</Link>,
    );
    expect(screen.getByRole("link", { name: "Next" })).toHaveAttribute(
      "data-fake-link",
    );
  });
  it.each([
    ["a non-http scheme", { href: "mailto:ada@example.com" }],
    ["an absolute external URL", { href: "https://example.com/next" }],
    ["a protocol-relative external URL", { href: "//example.com/next" }],
    ["a target other than _self", { href: "/next", target: "_blank" }],
    ["download", { href: "/next", download: "" }],
    ["reloadDocument", { href: "/next", reloadDocument: true }],
  ])("renders a plain anchor for %s", (_label, props) => {
    renderWithProvider(<Link {...props}>Next</Link>);
    expect(screen.getByRole("link", { name: "Next" })).not.toHaveAttribute(
      "data-fake-link",
    );
  });
  it("does not put reloadDocument on the DOM element", () => {
    render(<Link href="/next" reloadDocument>Next</Link>);
    expect(screen.getByRole("link", { name: "Next" })).not.toHaveAttribute(
      "reloaddocument",
    );
  });
  it("routes a Button's href through the provider too", () => {
    renderWithProvider(<Button href="/saved">Saved</Button>);
    const link = screen.getByRole("link", { name: "Saved" });
    expect(link).toHaveAttribute("href", "/saved");
    expect(link).toHaveAttribute("data-fake-link");
  });
  it("renders a plain anchor for a Button with reloadDocument", () => {
    renderWithProvider(
      <Button href="/x" reloadDocument>
        Saved
      </Button>,
    );
    expect(screen.getByRole("link", { name: "Saved" })).not.toHaveAttribute(
      "data-fake-link",
    );
  });
});

describe("isNativeLink", () => {
  it("uses the provider for relative links and same-origin URLs", () => {
    expect(isNativeLink("/x")).toBe(false);
    expect(isNativeLink("?tab=one")).toBe(false);
    expect(isNativeLink("#top")).toBe(false);
    expect(isNativeLink(`${window.location.origin}/x`)).toBe(false);
    expect(isNativeLink(`//${window.location.host}/x`)).toBe(false);
  });
  it("treats other schemes as native", () => {
    for (const href of [
      "mailto:ada@example.com",
      "tel:+123",
      "sms:+123",
      "ftp://example.com/file",
      "data:text/plain,hello",
    ])
      expect(isNativeLink(href), href).toBe(true);
  });
  it("treats other origins as native", () => {
    expect(isNativeLink("https://example.com/x")).toBe(true);
    expect(isNativeLink("http://example.com/x")).toBe(true);
    expect(isNativeLink("//example.com/x")).toBe(true);
  });
  it("treats an absolute URL as external when there is no window", () => {
    vi.stubGlobal("window", undefined);
    expect(isNativeLink("https://example.com/x")).toBe(true);
    expect(isNativeLink("/x")).toBe(false);
  });
  it("treats targets, downloads and reloadDocument as native", () => {
    expect(isNativeLink("/x", { target: "_blank" })).toBe(true);
    expect(isNativeLink("/x", { target: "_self" })).toBe(false);
    expect(isNativeLink("/x", { download: "" })).toBe(true);
    expect(isNativeLink("/x", { download: false })).toBe(false);
    expect(isNativeLink("/x", { reloadDocument: true })).toBe(true);
  });
  it("treats a same-origin absolute URL in a new tab or download as native", () => {
    const self = `${window.location.origin}/report`;
    expect(isNativeLink(self)).toBe(false);
    expect(isNativeLink(self, { target: "_blank" })).toBe(true);
    expect(isNativeLink(self, { download: "" })).toBe(true);
  });
});
