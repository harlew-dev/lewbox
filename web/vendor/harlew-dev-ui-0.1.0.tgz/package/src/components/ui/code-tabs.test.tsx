import { act, fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CodeTabs } from "./code-tabs";

const tabs = [
  { label: "CLI", language: "sh", code: "lewbox cluster list" },
  {
    label: "curl",
    language: "sh",
    code: "curl https://lewbox.example.com/v0/clusters",
  },
  { label: "Plain", code: "GET /v0/clusters" },
];

describe("CodeTabs", () => {
  it("shows the first tab's code with its copy button", () => {
    render(<CodeTabs tabs={tabs} />);
    expect(
      screen.getByRole("tablist", { name: "Code examples" }),
    ).toBeInTheDocument();
    expect(screen.getByRole("tab", { name: "CLI" })).toHaveAttribute(
      "aria-selected",
      "true",
    );
    expect(screen.getByText("lewbox cluster list")).toHaveClass("language-sh");
    expect(
      screen.getByRole("button", { name: "Copy CLI code" }),
    ).toBeInTheDocument();
    expect(screen.queryByText("GET /v0/clusters")).toBeNull();
  });

  it("switches snippet when a tab is clicked", () => {
    render(<CodeTabs tabs={tabs} label="List clusters" />);
    fireEvent.click(screen.getByRole("tab", { name: "curl" }));
    expect(screen.getByRole("tab", { name: "curl" })).toHaveAttribute(
      "aria-selected",
      "true",
    );
    expect(
      screen.getByText("curl https://lewbox.example.com/v0/clusters"),
    ).toBeInTheDocument();
    expect(screen.queryByText("lewbox cluster list")).toBeNull();
    expect(screen.getByRole("tabpanel")).toHaveTextContent(
      "curl https://lewbox.example.com/v0/clusters",
    );
  });

  it("moves between tabs with the arrow keys", async () => {
    // Base UI moves focus in a microtask after the key.
    const press = async (element: Element) => {
      fireEvent.keyDown(element, { key: "ArrowRight", keyCode: 39 });
      await act(async () => {
        await Promise.resolve();
      });
    };
    render(<CodeTabs tabs={tabs} />);
    const first = screen.getByRole("tab", { name: "CLI" });
    first.focus();
    await press(first);
    const second = screen.getByRole("tab", { name: "curl" });
    expect(second).toHaveFocus();
    await press(second);
    const third = screen.getByRole("tab", { name: "Plain" });
    expect(third).toHaveFocus();
    fireEvent.click(third);
    expect(screen.getByText("GET /v0/clusters")).not.toHaveAttribute("class");
  });
});
