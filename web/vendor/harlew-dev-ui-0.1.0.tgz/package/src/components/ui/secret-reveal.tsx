import type { ReactNode } from "react";
import { cx } from "../../lib/cx";
import { CopyText } from "./copy-text";
import { Text } from "./text";

// A secret shown once, right after it is made (an API key, a token): the
// value in monospace with a copy button, and one line saying it won't be
// shown again. `children` follows the panel (how to use the secret).
export function SecretReveal({
  secret,
  label = "Copy secret",
  children,
  className,
}: {
  secret: string;
  label?: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div data-slot="secret-reveal" className={cx(className, "space-y-6")}>
      <div className="rounded-lg bg-zinc-950/2.5 p-4 ring-1 ring-zinc-950/5 dark:bg-white/5 dark:ring-white/10">
        <CopyText value={secret} label={label} />
        <Text size="sm" className="mt-2">
          Copy it now. You won’t see it again.
        </Text>
      </div>
      {children}
    </div>
  );
}
