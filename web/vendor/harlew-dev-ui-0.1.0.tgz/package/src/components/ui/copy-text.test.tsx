import { act, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { CopyText } from "./copy-text";
afterEach(() => {
  vi.unstubAllGlobals();
});
describe("CopyText", () => {
  it("shows the value and copies it", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    vi.stubGlobal("navigator", { clipboard: { writeText } });
    render(<CopyText value="sb-0123456789" label="Copy sandbox ID" />);
    expect(screen.getByText("sb-0123456789")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Copy sandbox ID" }));
    await act(async () => {
      await Promise.resolve();
    });
    expect(writeText).toHaveBeenCalledWith("sb-0123456789");
    expect(screen.getByRole("status")).toHaveTextContent("Copied");
  });
  it("copies the full value when it shows something shorter", async () => {
    const writeText = vi.fn().mockRejectedValue(new Error("denied"));
    vi.stubGlobal("navigator", { clipboard: { writeText } });
    render(<CopyText value="sb-0123456789">sb-0123…</CopyText>);
    expect(screen.getByText("sb-0123…")).toHaveAttribute(
      "title",
      "sb-0123456789",
    );
    fireEvent.click(screen.getByRole("button", { name: "Copy" }));
    await act(async () => {
      await Promise.resolve();
    });
    expect(writeText).toHaveBeenCalledWith("sb-0123456789");
    expect(screen.getByRole("alert")).toHaveTextContent("Couldn’t copy");
  });
});
