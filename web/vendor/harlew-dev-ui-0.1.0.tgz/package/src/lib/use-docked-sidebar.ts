import { useState } from "react";

// Where this device remembers that the desktop sidebar is hidden. Docked is
// the default, so only "hidden" is stored.
export const sidebarStorageKey = "ui:sidebar";

// Read while rendering, so the first paint already has the remembered state:
// the layout renders in the browser and no effect flips it after mount, which
// would flash the sidebar and play its slide. Storage can be unavailable
// (blocked, or a private window), and then the sidebar is docked.
function readDocked(key: string) {
  try {
    return localStorage.getItem(key) !== "hidden";
  } catch {
    return true;
  }
}

function writeDocked(key: string, docked: boolean) {
  try {
    if (docked) localStorage.removeItem(key);
    else localStorage.setItem(key, "hidden");
  } catch {
    // Not remembered, but the toggle still works for this visit.
  }
}

// Whether the desktop sidebar is docked, remembered across visits on this
// device under `key` (a layout preference, not user data).
export function createDockedSidebar(key: string) {
  return function useDockedSidebarForKey() {
    const [docked, setDocked] = useState(() => readDocked(key));
    function toggle() {
      writeDocked(key, !docked);
      setDocked(!docked);
    }
    return { docked, toggle };
  };
}

// The default key, so two layouts in one app can keep separate preferences.
export function useDockedSidebar(key: string = sidebarStorageKey) {
  const [docked, setDocked] = useState(() => readDocked(key));
  function toggle() {
    writeDocked(key, !docked);
    setDocked(!docked);
  }
  return { docked, toggle };
}
