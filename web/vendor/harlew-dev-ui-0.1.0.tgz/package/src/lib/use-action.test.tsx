import { act, renderHook } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { useAction } from "./use-action";
// An action that waits until the test settles it.
function deferred<T>() {
  let resolve: (value: T) => void = () => {};
  let reject: (error: unknown) => void = () => {};
  const promise = new Promise<T>((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
}
describe("useAction()", () => {
  it("is busy while the action runs and resolves with its value", async () => {
    const pending = deferred<string>();
    const { result } = renderHook(() => useAction(() => pending.promise));
    let run: Promise<unknown> = Promise.resolve();
    act(() => {
      run = result.current.run();
    });
    expect(result.current.busy).toBe(true);
    await act(async () => {
      pending.resolve("saved");
      await run;
    });
    expect(result.current.busy).toBe(false);
    await expect(run).resolves.toEqual({ ok: true, value: "saved" });
  });
  it("ignores a second run while one is in flight", async () => {
    const pending = deferred<void>();
    let calls = 0;
    const { result } = renderHook(() =>
      useAction(() => {
        calls += 1;
        return pending.promise;
      }),
    );
    let first: Promise<unknown> = Promise.resolve();
    let second: Promise<unknown> = Promise.resolve();
    // Both in the same tick, before React re-renders: a double click.
    act(() => {
      first = result.current.run();
      second = result.current.run();
    });
    await expect(second).resolves.toEqual({ ok: false });
    await act(async () => {
      pending.resolve();
      await first;
    });
    expect(calls).toBe(1);
  });
  it("keeps the failure for the notice, and clears it on success", async () => {
    let fail = true;
    const { result } = renderHook(() =>
      useAction(async () => {
        if (fail) throw new Error("Too many attempts.");
      }),
    );
    await act(async () => {
      await expect(result.current.run()).resolves.toMatchObject({
        ok: false,
        error: { message: "Too many attempts." },
      });
    });
    expect(result.current.error.message).toBe("Too many attempts.");
    expect(result.current.busy).toBe(false);
    fail = false;
    await act(async () => {
      await result.current.run();
    });
    expect(result.current.error.message).toBe("");
  });
  it("leaves failures that onError handles out of the error", async () => {
    const handled: unknown[] = [];
    const { result } = renderHook(() =>
      useAction(
        async () => {
          throw Object.assign(new Error("Current password is incorrect."), {
            field: "password",
          });
        },
        {
          onError: (error) => {
            handled.push(error);
            return typeof (error as { field?: string }).field === "string";
          },
        },
      ),
    );
    await act(async () => {
      await result.current.run();
    });
    expect(handled).toHaveLength(1);
    expect(result.current.error.message).toBe("");
  });
  it("maps the app's error type with toError", async () => {
    const { result } = renderHook(() =>
      useAction(
        async () => {
          throw { message: "Server unavailable.", requestId: "req-1" };
        },
        { toError: (error) => error as { message: string; requestId: string } },
      ),
    );
    await act(async () => {
      await expect(result.current.run()).resolves.toMatchObject({
        ok: false,
        error: { message: "Server unavailable.", requestId: "req-1" },
      });
    });
    expect(result.current.error).toMatchObject({
      message: "Server unavailable.",
      requestId: "req-1",
    });
  });
});
