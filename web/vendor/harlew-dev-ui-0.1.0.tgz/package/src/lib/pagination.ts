// Mirrors the usual page envelope: one page of results plus its position.
export type Pages = {
  current: number;
  total: number;
  perPage: number;
  items: number;
};

export type Page<T> = { data: T[]; pages: Pages };

export type SortDirection = "ascending" | "descending";

// Matches the server's search limit; longer terms are cut to it.
const maxSearch = 100;

// A search term as the server accepts it: trimmed, without control
// characters, and at most 100 characters.
export function cleanSearch(value: string): string {
  return Array.from(value.replace(/\p{Cc}/gu, "").trim())
    .slice(0, maxSearch)
    .join("")
    .trim();
}

// Page numbers for a page selector: the first and last pages, `siblings`
// either side of the current page, and "gap" for skipped runs.
export function pageRange(pages: Pages, siblings = 1): (number | "gap")[] {
  const total = Math.max(1, pages.total);
  const current = Math.min(Math.max(1, pages.current), total);
  const start = Math.max(2, current - siblings);
  const end = Math.min(total - 1, current + siblings);
  const range: (number | "gap")[] = [1];
  // A gap that would hide a single page shows that page instead.
  if (start > 3) range.push("gap");
  else for (let n = 2; n < start; n++) range.push(n);
  for (let n = start; n <= end; n++) range.push(n);
  if (end < total - 2) range.push("gap");
  else for (let n = end + 1; n < total; n++) range.push(n);
  if (total > 1) range.push(total);
  return range;
}
