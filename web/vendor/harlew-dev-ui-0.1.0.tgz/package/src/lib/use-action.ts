import { useRef, useState } from "react";
import type { ActionError } from "../components/ui/feedback";
import { useDelayedLoading } from "./use-delayed-loading";
// What a mapped failure needs: the message shown under the form or in a
// notice, and an optional reference to quote to support.
export type ActionFailure = { message: string; requestId?: string };
export type ActionOptions = {
  // Handles a failure itself (a toast, or an error shown on one field).
  // Return true to keep it out of `error`, which also clears the last one.
  onError?: (error: unknown) => boolean | void;
  // Maps the app's own error type (an API error with a message and request
  // ID) to what the notice shows. Without it, an Error's `message` is used.
  toError?: (error: unknown) => ActionFailure;
};
export type ActionResult<T> =
  | { ok: true; value: T }
  | { ok: false; error?: ActionError };
// A form submission or button action: `busy` from the moment it runs until it
// settles (for logic, e.g. not closing a dialog mid-save), `loading` once it
// has run for 200 ms and for at least 400 ms (for <Button loading> and disabled
// fields, so a quick request doesn't flicker; useDelayedLoading), the last
// failure in `error` (for <ErrorNotice>), and `run`, which ignores calls while
// one is in flight, so a double click submits once. `run` awaits everything
// the action awaits and never throws: it resolves { ok: true, value } or
// { ok: false, error }.
//   const save = useAction((input: ProjectInput) => api.projects(id).store(input));
//   const result = await save.run(form);
export function useAction<A extends unknown[], T>(
  action: (...args: A) => Promise<T>,
  { onError, toError }: ActionOptions = {},
) {
  const [busy, setBusy] = useState(false);
  const loading = useDelayedLoading(busy);
  // A ref, not state: two clicks in the same tick both see the same state.
  const running = useRef(false);
  const lastKey = useRef(0);
  const [error, setError] = useState<ActionError>({ message: "", key: 0 });
  function clear() {
    setError((last) => ({ ...last, message: "", requestId: undefined }));
  }
  function fail(failure: unknown): ActionError {
    lastKey.current += 1;
    const mapped = toError
      ? toError(failure)
      : {
          message: failure instanceof Error ? failure.message : String(failure),
        };
    const next = { ...mapped, key: lastKey.current };
    setError(next);
    return next;
  }
  async function run(...args: A): Promise<ActionResult<T>> {
    if (running.current) return { ok: false };
    running.current = true;
    setBusy(true);
    try {
      const value = await action(...args);
      clear();
      return { ok: true, value };
    } catch (failure) {
      if (onError?.(failure) === true) {
        clear();
        return { ok: false };
      }
      return { ok: false, error: fail(failure) };
    } finally {
      running.current = false;
      setBusy(false);
    }
  }
  return { run, busy, loading, error, clear };
}
